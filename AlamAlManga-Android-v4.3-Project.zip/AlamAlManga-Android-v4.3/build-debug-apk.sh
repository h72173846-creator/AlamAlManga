#!/usr/bin/env sh
set -eu
gradle --no-daemon --stacktrace :app:assembleDebug
printf '\nAPK output: app/build/outputs/apk/debug/app-debug.apk\n'
