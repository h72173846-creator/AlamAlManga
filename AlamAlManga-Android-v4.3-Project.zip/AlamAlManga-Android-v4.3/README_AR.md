# عالم المانجا v4.3 — مشروع Android

هذا المشروع يحوّل واجهة عالم المانجا v4.3 إلى تطبيق Android حقيقي يعتمد على WebView، مع واجهة عربية واتجاه RTL، وتخزين المتصفح المحلي، واستيراد الملفات من مدير ملفات الهاتف. يتضمن جسرًا أصليًا لحفظ فصول TXT والنسخ الاحتياطية JSON داخل `Downloads/AlamAlManga` على Android 10 فأحدث.

## بناء APK تلقائيًا من GitHub

1. فك ضغط ملف ZIP على جهازك. يجب أن يكون `settings.gradle.kts` و`build.gradle.kts` في جذر المشروع، وليس داخل مجلد إضافي.
2. ارفع محتويات المجلد إلى مستودع GitHub تملكه، على الفرع `main` أو `master`، أو افتح المشروع في Android Studio.
3. بعد رفع الملفات، افتح تبويب **Actions** واختر **Build AlamAlManga APK** ثم **Run workflow**. البناء يبدأ تلقائيًا أيضًا عند push إلى main/master.
4. افتح عملية البناء المكتملة ونزّل العنصر **AlamAlManga-v4.3-debug-apk** من قسم Artifacts، ثم فك ضغطه وثبّت `app-debug.apk` على Android.

## البناء من Android Studio

افتح مجلد المشروع، دع Gradle يزامن التبعيات، ثم اختر **Build > Build Bundle(s) / APK(s) > Build APK(s)**. الملف الناتج: `app/build/outputs/apk/debug/app-debug.apk`. يتطلب البناء اتصال إنترنت لتنزيل Gradle وAndroid SDK والتبعيات في أول مرة.

## ما الذي لا ندّعيه؟

- لم يتم إنشاء ملف APK في بيئة الإنشاء الحالية، لأنها لا تحتوي على Android SDK أو Gradle ولا يمكنها الوصول إلى مستودعات التنزيل. لذلك ملف APK غير مرفق في هذه الحزمة.
- أعددنا مشروع Android وGitHub Actions لبناء APK حقيقي، لكن يجب أن ينجح البناء في بيئة متصلة بالإنترنت أولًا.
- لم يُختبر التطبيق على هاتف فعلي بعد.
- المكتبة لا تحتوي تلقائيًا على نصوص أو صفحات كاملة لأعمال محمية بحقوق النشر. تقدر تستورد ملفات الفصول التي تملك حق استخدامها، والبيانات العامة تُكتشف عند الاتصال بالإنترنت حيثما توفرت.

## الإعدادات الفنية

- Package: `com.alamalmanga.app`
- Version: `4.3` (versionCode 43)
- Minimum Android API: 23
- Target Android API: 34
- Java: 17
- Android Gradle Plugin: 8.7.3 / Gradle 8.9
