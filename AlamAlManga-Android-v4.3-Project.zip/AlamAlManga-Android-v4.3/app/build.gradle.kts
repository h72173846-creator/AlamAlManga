plugins {
    id("com.android.application")
}

android {
    namespace = "com.alamalmanga.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.alamalmanga.app"
        minSdk = 23
        targetSdk = 34
        versionCode = 43
        versionName = "4.3"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
}
