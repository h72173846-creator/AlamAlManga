package com.alamalmanga.app

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/** Periodic metadata-only scan. It stores chapter IDs and official/source links, not page images. */
class ChapterScanWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences("alam_al_manga", Context.MODE_PRIVATE)
        return try {
            val endpoint = URL("https://api.mangadex.org/chapter?limit=100&order%5BreadableAt%5D=desc&includes%5B%5D=manga&translatedLanguage%5B%5D=en&translatedLanguage%5B%5D=ar")
            val connection = (endpoint.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 15000
                readTimeout = 20000
                setRequestProperty("User-Agent", "AlamAlManga/0.8.0 (chapter metadata scanner)")
                setRequestProperty("Accept", "application/json")
            }
            val code = connection.responseCode
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()
            val data = JSONObject(body).optJSONArray("data") ?: JSONArray()
            val existing = JSONArray(prefs.getString("discovered_chapters", "[]") ?: "[]")
            val known = HashSet<String>()
            val oldItems = mutableListOf<JSONObject>()
            for (i in 0 until existing.length()) {
                val obj = existing.optJSONObject(i) ?: continue
                val id = obj.optString("id")
                if (id.isNotBlank() && known.add(id) && oldItems.size < 200) oldItems.add(obj)
            }
            val newItems = mutableListOf<JSONObject>()
            for (i in 0 until data.length()) {
                val chapterObj = data.optJSONObject(i) ?: continue
                val id = chapterObj.optString("id")
                if (id.isBlank() || !known.add(id)) continue
                val attrs = chapterObj.optJSONObject("attributes") ?: JSONObject()
                val relationships = chapterObj.optJSONArray("relationships") ?: JSONArray()
                var mangaId = ""
                var mangaTitle = "عمل من MangaDex"
                for (j in 0 until relationships.length()) {
                    val rel = relationships.optJSONObject(j) ?: continue
                    if (rel.optString("type") == "manga") {
                        mangaId = rel.optString("id")
                        val titles = rel.optJSONObject("attributes")?.optJSONObject("title")
                        if (titles != null) {
                            mangaTitle = titles.optString("en", "").takeIf { it.isNotBlank() }
                                ?: titles.optString("ja-ro", "").takeIf { it.isNotBlank() }
                                ?: titles.keys().asSequence().mapNotNull { titles.optString(it).takeIf { value -> value.isNotBlank() } }.firstOrNull()
                                ?: mangaTitle
                        }
                        break
                    }
                }
                val item = JSONObject()
                    .put("id", id)
                    .put("mangaId", mangaId)
                    .put("manga", mangaTitle)
                    .put("chapter", attrs.optString("chapter", ""))
                    .put("title", attrs.optString("title", ""))
                    .put("date", attrs.optString("readableAt", attrs.optString("publishAt", "")))
                    .put("url", "https://mangadex.org/chapter/$id")
                newItems.add(item)
            }
            val finalArray = JSONArray()
            for (obj in newItems) if (finalArray.length() < 200) finalArray.put(obj)
            for (obj in oldItems) if (finalArray.length() < 200) finalArray.put(obj)
            val added = newItems.size
            val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
            prefs.edit().putString("discovered_chapters", finalArray.toString())
                .putString("scan_last_at", stamp)
                .putString("scan_status", "نجح الفحص؛ فصول جديدة: $added")
                .apply()
            Result.success()
        } catch (e: Exception) {
            prefs.edit().putString("scan_last_at", SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date()))
                .putString("scan_status", "تعذّر الفحص: ${e.message ?: "خطأ اتصال"}")
                .apply()
            if (runAttemptCount < 3) Result.retry() else Result.failure()
        }
    }

}

object ChapterScanScheduler {
    private const val UNIQUE_NAME = "alam_manga_hourly_chapter_scan"
    fun ensureScheduled(context: Context) {
        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        val request = PeriodicWorkRequestBuilder<ChapterScanWorker>(1, TimeUnit.HOURS)
            .setConstraints(constraints)
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            UNIQUE_NAME, ExistingPeriodicWorkPolicy.KEEP, request
        )
    }
}
