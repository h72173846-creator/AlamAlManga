package com.alamalmanga.app

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.net.Uri
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread
import java.net.URLEncoder

private data class Chapter(val title: String, val paragraphs: List<String>)
private data class OnlineWork(
    val title: String,
    val kind: String,
    val genre: String,
    val description: String,
    val platform: String,
    val readUrl: String,
    val coverUrl: String? = null,
    val fallbackUrl: String? = null
)

private data class Comic(
    val title: String,
    val kind: String,
    val genre: String,
    val description: String,
    val chapters: List<Chapter>
)

class MainActivity : Activity() {
    private val bg = Color.rgb(14, 16, 25)
    private val panel = Color.rgb(27, 30, 44)
    private val purple = Color.rgb(157, 112, 255)
    private val white = Color.rgb(247, 247, 252)
    private val muted = Color.rgb(181, 185, 205)
    private val warmBg = Color.rgb(245, 235, 211)
    private val warmPanel = Color.rgb(255, 248, 230)
    private val warmText = Color.rgb(63, 48, 32)

    private lateinit var prefs: SharedPreferences
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private val favorites = linkedSetOf<String>()
    private val downloads = linkedSetOf<String>()
    private val history = mutableListOf<String>()
    private var currentTab = "الرئيسية"
    private var filter = "الكل"
    private var readerFontSize = 18
    private var sepiaReader = false
    private var activeComic: Comic? = null
    private var activeChapterIndex = 0
    private var activeScreen = "home"
    private var activeOnlineWork: OnlineWork? = null
    private var activeWebView: WebView? = null
    private val remoteCoverCache = ConcurrentHashMap<String, Bitmap>()
    private val remoteCoverUrlCache = ConcurrentHashMap<String, String>()
    private var importTarget: Pair<Comic, Int>? = null
    private val importPagesRequestCode = 4317

    // All sample chapters below are original text written for this demo app.
    private val comics = listOf(
        Comic(
            "رحلة الظلال", "مانجا", "مغامرات", "فتاة تكتشف أن الظلال تحفظ ذكريات المدينة المفقودة.",
            listOf(
                Chapter("الفصل 1: الظل الذي تأخر", listOf(
                    "في مدينة لا تنام، كانت ليان تعود إلى منزلها كل مساء عبر زقاق ضيق. في تلك الليلة لاحظت أن ظلها لم يتبعها؛ بقي واقفًا تحت مصباح الشارع، كأنه ينتظر شخصًا آخر.",
                    "اقتربت بحذر. لم يتحرك الظل، لكنه رسم بإصبعه بابًا على الجدار. ظهرت على الطوب خطوط زرقاء تشبه خريطة قديمة، ثم سمعت ليان صوتًا يهمس باسمها من الجهة الأخرى.",
                    "لم يكن الباب موجودًا قبل لحظة. أخذت نفسًا عميقًا ومدت يدها نحو المقبض البارد. خلفها، عادت كل ظلال الزقاق إلى أماكنها دفعة واحدة، بينما انفتح الباب على سماء مليئة بنجوم لم ترها من قبل."
                )),
                Chapter("الفصل 2: خريطة الذاكرة", listOf(
                    "امتد الطريق خلف الباب فوق بحر من الضباب. كانت النجوم تضيء كلما خطت ليان خطوة، وتخفت حين تتراجع. على حجر صغير وجدت خريطة تحمل أسماء شوارع مدينتها، لكن بجانب كل اسم تاريخًا يعود إلى مئة عام.",
                    "ظهر حارس يرتدي معطفًا رماديًا وقال إن الظلال ليست نسخًا من أصحابها، بل ذكريات نسوها مع مرور الزمن. ظل ليان تأخر لأنه تذكر شيئًا حاولت هي نسيانه.",
                    "أشارت الخريطة إلى برج الساعة في قلب المدينة. قبل أن تسأل عن السبب، انطفأت نجمة واحدة وسقطت في البحر. قال الحارس: حين تنطفئ النجوم كلها، ستنسى المدينة نفسها."
                )),
                Chapter("الفصل 3: برج الساعة", listOf(
                    "عادت ليان إلى المدينة مع أول ضوء للفجر. كان برج الساعة متوقفًا عند الثالثة وسبع عشرة دقيقة، والناس يمرون تحته دون أن يلاحظوا. وحدها القطط كانت تحدق في قمته.",
                    "داخل البرج، وجدت درجًا لا يظهر إلا في انعكاس الزجاج. صعدت وهي تسمع أصواتًا من طفولتها: ضحكة أمها، أغنية قديمة، ووعدًا قطعته لنفسها ثم نسيته.",
                    "في أعلى البرج، انتظرها ظلها. لم يكن يريد العودة فحسب؛ كان يحاول تحذيرها من شيء يتحرك تحت المدينة. وعندما دقت الساعة أخيرًا، انفتحت الأرض عن ضوء أزرق عميق."
                ))
            )
        ),
        Comic(
            "بوابة التنين", "مانهوا", "فانتازيا", "متدرّب خرائط يعثر على بوابة تستجيب للوعود الصادقة.",
            listOf(
                Chapter("الفصل 1: الوعد الحجري", listOf(
                    "كان يونس أصغر رسامي الخرائط في مملكة السحاب. لم يكن يجيد المبارزة أو السحر، لكنه يستطيع رسم طريق لم يره أحد من قبل. وفي يوم جرفته عاصفة إلى وادٍ لا يظهر على أي خريطة.",
                    "في نهاية الوادي وقف قوس حجري عليه نقش تنين بلا أجنحة. حين لمس يونس الحجر، سمع صوتًا يسأله: ما الشيء الذي لن تتخلى عنه مهما كان الثمن؟ أجاب بأنه لن يترك أخته تبحث عنه وحدها.",
                    "اشتعل النقش بضوء ذهبي، وفتحت البوابة على غابة معلقة في السماء. ومن داخلها خرجت فراشة معدنية تحمل رسالة مختومة باسم عائلته."
                )),
                Chapter("الفصل 2: الغابة المعلّقة", listOf(
                    "كانت الأشجار تنمو من جزر صخرية تطفو فوق بحر من الغيوم. ربط يونس خريطته بحزامه وتبع الفراشة حتى شجرة ضخمة جذورها تشبه السلالم.",
                    "وجد عند الجذع حارسًا صغيرًا اسمه رُبى. أخبرته أن البوابة تختبر الوعود، وأن كل وعد مكسور يترك شقًا في السماء. ظهر شق جديد فوقهما، وسقطت منه أحجار سوداء.",
                    "رسم يونس طريقًا بالقلم على الهواء، فتحول الخط إلى جسر من الحبر. عبر الاثنان قبل أن تنهار الجزيرة، لكن الرسالة في يد الفراشة بدأت تحترق من أطرافها."
                )),
                Chapter("الفصل 3: قلب البوابة", listOf(
                    "قادتهما الرسالة إلى معبد مخفي داخل جذور الشجرة. على الجدار لوحة لعائلة يونس، وبجانبها صورة امرأة تشبه أخته تمامًا.",
                    "كشف الحارس أن البوابة لا تفتح إلى أماكن بعيدة فقط، بل إلى القرارات التي لم يتخذها الناس. كان على يونس أن يختار بين طريق يعيده إلى بيته وطريق يكشف سر اختفاء والده.",
                    "طوى الخريطة ووضعها في جيبه. قال إنه سيبحث عن الحقيقة، لكنه سيعود إلى أخته مهما حدث. عندها ظهر على البوابة جناحان من نور، وسمع التنين يناديه باسمه الكامل."
                ))
            )
        ),
        Comic(
            "مدينة النجوم", "مانجا", "خيال علمي", "ميكانيكية شابة تحاول إعادة تشغيل منارة تحمي مدينة عائمة.",
            listOf(
                Chapter("الفصل 1: آخر منارة", listOf(
                    "منذ ثلاثين سنة، ظلت مدينة أوريون تطفو فوق الغلاف السحابي بفضل منارة هائلة في مركزها. وحين بدأت أضواؤها تنطفئ واحدة تلو الأخرى، لم يجرؤ أحد على الاقتراب من غرفة المحرك.",
                    "دخلت ميرا الغرفة ومعها حقيبة أدوات ودفتر تركه لها جدها. لم تجد محركًا، بل كرة صغيرة تدور حول نفسها وتطلق أصواتًا تشبه نداء الحيتان.",
                    "كتب جدها في الدفتر: لا تحاولي تشغيل المنارة بالقوة؛ اسأليها عمّا فقدته. وضعت ميرا يدها على الكرة، فظهر على الزجاج مشهد لمدينة أخرى تحت السحب، مدينة لم تسجلها أي أجهزة."
                )),
                Chapter("الفصل 2: الرسالة من الأسفل", listOf(
                    "صنعت ميرا جهاز إرسال من قطع قديمة، وأرسلت نمط الضوء الذي رأته على الكرة. بعد دقائق عاد الرد في صورة ثلاث ومضات طويلة وواحدة قصيرة.",
                    "فسّر مهندس المدينة الإشارة بأنها تحذير، لكن ميرا لاحظت أن النمط نفسه مرسوم في هامش دفتر جدها. كان جدها قد سافر إلى الأسفل قبل اختفاء المنارة بسنوات.",
                    "عند حافة المدينة وجدت مصعد صيانة مهجورًا. حين ضغطت الزر، اشتغل لأول مرة منذ عقود، وبدأ يهبط عبر الغيوم نحو أضواء تلمع في عمق الظلام."
                ))
            )
        ),
        Comic(
            "صياد الأبراج", "مانهوا", "أكشن", "طالبة تتسلق أبراجًا غامضة بحثًا عن سبب ظهورها في العالم.",
            listOf(
                Chapter("الفصل 1: الطابق صفر", listOf(
                    "ظهرت الأبراج في كل أنحاء العالم خلال ليلة واحدة. كان لكل برج باب أسود وشعار مختلف، ولم يستطع أحد فتحها حتى وقفت ندى أمام برج بلا شعار.",
                    "لم يظهر على جهازها مستوى أو مهمة، بل جملة واحدة: الطابق صفر مفتوح. دخلت فوجدت ساحة هادئة تتوسطها شجرة، وتحتها مقعد يحمل اسمها.",
                    "عندما جلست، ظهر رجل آلي مكسور وقال إن البرج لا يختبر القوة، بل القدرة على ملاحظة ما يتجاهله الآخرون. أشار إلى ظل الشجرة، حيث كانت هناك خطوات صغيرة تتجه إلى جدار مصمت."
                )),
                Chapter("الفصل 2: اختبار الملاحظة", listOf(
                    "لمست ندى الجدار عند نهاية الخطوات، فاختفى وظهر ممر مليء بأبواب متشابهة. لم تختَر الباب الأكبر أو الأكثر لمعانًا؛ راقبت الغبار ولاحظت أن بابًا واحدًا لا توجد أمامه آثار أقدام.",
                    "خلفه كانت غرفة تحكم قديمة، وعلى الطاولة سجل يحمل تواريخ ظهور الأبراج. كل سجل ينتهي في اليوم نفسه: يوم اختفاء شخص لم يتذكره أحد.",
                    "وصلت إلى آخر صفحة فوجدت صورتها وهي طفلة. قبل أن تقرأ التعليق، أضاءت شاشة صغيرة: مرحبًا بعودتك، المشغّل رقم واحد."
                ))
            )
        ),
        Comic(
            "مذكرات الساحر", "مانهوا", "فانتازيا", "ساحر مبتدئ يكتشف أن مذكراته تكتب أحداث الغد.",
            listOf(
                Chapter("الفصل 1: صفحة الغد", listOf(
                    "ورث سامر غرفة ضيقة ومجموعة كتب من معلمه الراحل. بين الكتب وجد دفترًا جلديًا فارغ الصفحات. كتب اسمه في الصفحة الأولى، فظهرت تحته جملة تصف المطر الذي سيبدأ بعد ساعة.",
                    "انتظر عند النافذة، فهطل المطر في الموعد تمامًا. كتب سؤالًا عن سبب اختفاء معلمه، لكن الحبر تراجع وحده وترك مكانه دائرة سوداء.",
                    "في الليل، سمع طرقًا على الباب. كانت امرأة تحمل مظلة جافة رغم المطر، وقالت إن الدفتر لا يتنبأ بالمستقبل؛ إنه يختار أي مستقبل سيصبح حقيقيًا."
                )),
                Chapter("الفصل 2: ثمن الحبر", listOf(
                    "أخبرت المرأة سامر أن كل كلمة في الدفتر تغيّر احتمالًا في العالم. الكلمات الصغيرة تغيّر تفاصيل بسيطة، أما الأسماء فتستطيع فتح أبواب كان يجب أن تبقى مغلقة.",
                    "حاول سامر كتابة اسم معلمه، لكن القلم رفض ترك أثر. بدلًا من ذلك، ظهر اسم جديد لم يسمعه من قبل: الحارس الأخير.",
                    "خرجت المرأة من الغرفة واختفت المظلة معها. في الدفتر، كُتبت جملة أخيرة بخط سامر نفسه: لا تثق بأول نسخة من قصتك."
                ))
            )
        ),
        Comic(
            "قناع الليل", "مانجا", "غموض", "رسام أقنعة يساعد حيّه على حل ألغاز تظهر بعد منتصف الليل.",
            listOf(
                Chapter("الفصل 1: القناع الأبيض", listOf(
                    "كان متجر نادر يغلق أبوابه عند منتصف الليل، إلا أن قناعًا أبيض كان يظهر كل صباح على العتبة. لم يعرف من صنعه، لكنه لاحظ أن كل قناع يقوده إلى لغز في الحي.",
                    "في الليلة السابعة، وجد القناع يحمل خيطًا أحمر متصلًا بباب المكتبة القديمة. في الداخل، كانت الكتب مرتبة حسب الأصوات لا حسب العناوين.",
                    "فتح نادر كتابًا صامتًا، فسقطت منه ورقة عليها رسم لشارع الحي من الأعلى. في منتصف الرسم توجد نافذة مضاءة في منزل مهجور منذ سنوات."
                )),
                Chapter("الفصل 2: نافذة لا تنام", listOf(
                    "وصل نادر إلى المنزل المهجور قبل الفجر. من الخارج بدا خاليًا، لكن النافذة المضيئة كشفت غرفة مرتبة ومكتبًا عليه أدوات رسم تشبه أدواته تمامًا.",
                    "على الجدار كانت هناك أقنعة لكل شخص في الحي، وتحت كل قناع ملاحظة عن شيء فقده صاحبه. لم تكن أسرارًا مخيفة؛ كانت وعودًا نسي أصحابها الوفاء بها.",
                    "عندما رفع القناع الأبيض عن الخطاف، انطفأت النافذة وسمع صوتًا خلفه يقول: الآن عرفت أين تبدأ الحكاية، لكن هل تستطيع إنهاءها؟"
                ))
            )
        )
    )

    // Dynamically discovered works are fetched from the public MangaDex catalog and cached locally.
    private val discoveredWorks = mutableListOf<OnlineWork>()
    private val mainHandler = Handler(Looper.getMainLooper())

    // Online catalog: metadata and links to the platforms that legally serve each series.
    // The in-app WebView loads the publisher/platform page itself; this app does not mirror chapter files.
    private val onlineWorks = listOf(
        OnlineWork(
            "Boruto: Two Blue Vortex", "مانجا", "أكشن • نينجا",
            "بوروتو يعود بعد تغيّر ذكريات أهل القرية. الفصول المتاحة تختلف حسب البلد واللغة.",
            "MANGA Plus by SHUEISHA",
            "https://mangaplus.shueisha.co.jp/titles/100269",
            "https://shop.viz.com/cdn/shop/files/white-9781974747184_1445x.jpg?v=1743521563",
            "https://www.viz.com/shonenjump/chapters/boruto-two-blue-vortex"
        ),
        OnlineWork(
            "One Piece", "مانجا", "مغامرات • خيال",
            "رحلة لوفي وطاقمه بحثًا عن الكنز الأسطوري. التوفر حسب سياسة المنصة والمنطقة.",
            "MANGA Plus by SHUEISHA", "https://mangaplus.shueisha.co.jp/titles/100020"
        ),
        OnlineWork(
            "Jujutsu Kaisen", "مانجا", "أكشن • خارق للطبيعة",
            "يوجي إيتادوري يجد نفسه داخل عالم اللعنات والسحرة.",
            "MANGA Plus by SHUEISHA", "https://mangaplus.shueisha.co.jp/titles/100034",
            "https://shop.viz.com/cdn/shop/files/white-9781974710027_1445x.jpg?v=1743522402"
        ),
        OnlineWork(
            "Chainsaw Man", "مانجا", "أكشن • فانتازيا مظلمة",
            "دينجي يحاول تغيير حياته بعد أن تتشابك مع عالم الشياطين.",
            "MANGA Plus by SHUEISHA", "https://mangaplus.shueisha.co.jp/titles/100037"
        ),
        OnlineWork(
            "Omniscient Reader", "مانهوا", "أكشن • فانتازيا",
            "قارئ يجد أن أحداث الرواية التي يتابعها أصبحت واقعًا.",
            "WEBTOON", "https://www.webtoons.com/en/action/omniscient-reader/list?title_no=2154"
        ),
        OnlineWork(
            "Tower of God", "مانهوا", "مغامرات • فانتازيا",
            "رحلة داخل برج غامض، حيث يواجه المتسلقون اختبارات متصاعدة.",
            "WEBTOON", "https://www.webtoons.com/en/fantasy/tower-of-god/list?title_no=95"
        ),
        OnlineWork(
            "Eleceed", "مانهوا", "أكشن • قوى خارقة",
            "شاب سريع الحركة يلتقي بمستخدم قوى مخفي في هيئة قط.",
            "WEBTOON", "https://www.webtoons.com/en/action/eleceed/list?title_no=1571"
        ),
        OnlineWork(
            "Lookism", "مانهوا", "دراما • مدرسي",
            "قصة عن المظهر والهوية والتنمر وتغيّر نظرة المجتمع.",
            "WEBTOON", "https://www.webtoons.com/en/drama/lookism/list?title_no=1049"
        ),
        OnlineWork(
            "The God of High School", "مانهوا", "أكشن • بطولات",
            "بطولة قتالية تجمع مقاتلين بقدرات غير عادية.",
            "WEBTOON", "https://www.webtoons.com/en/action/the-god-of-high-school/list?title_no=66"
        ),
        OnlineWork("Dandadan", "مانجا", "أكشن • خيال خارق", "مغامرة تجمع ظواهر خارقة وكائنات غريبة.", "MANGA Plus", "https://mangaplus.shueisha.co.jp/"),
        OnlineWork("Sakamoto Days", "مانجا", "أكشن • كوميديا", "قاتل سابق يحاول حماية حياته العائلية الهادئة.", "MANGA Plus", "https://mangaplus.shueisha.co.jp/"),
        OnlineWork("Spy x Family", "مانجا", "كوميديا • تجسس", "عائلة غير تقليدية تخفي أسرارًا عن بعضها.", "MANGA Plus", "https://mangaplus.shueisha.co.jp/"),
        OnlineWork("My Hero Academia", "مانجا", "أبطال • أكشن", "طلاب يتدربون ليصبحوا أبطالًا محترفين.", "VIZ", "https://www.viz.com/manga-books/manga/my-hero-academia"),
        OnlineWork("Dragon Ball Super", "مانجا", "أكشن • مغامرات", "مغامرات جديدة في عالم دراغون بول.", "VIZ", "https://www.viz.com/dragon-ball"),
        OnlineWork("Black Clover", "مانجا", "فانتازيا • سحر", "فتى بلا سحر يحلم بأن يصبح إمبراطور السحر.", "MANGA Plus", "https://mangaplus.shueisha.co.jp/"),
        OnlineWork("Blue Box", "مانجا", "رياضة • رومانسية خفيفة", "طالب رياضي يوازن بين التدريب ومشاعره.", "MANGA Plus", "https://mangaplus.shueisha.co.jp/"),
        OnlineWork("Kaiju No. 8", "مانجا", "أكشن • وحوش", "عامل نظافة يحاول الانضمام إلى قوة مكافحة الوحوش.", "MANGA Plus", "https://mangaplus.shueisha.co.jp/"),
        OnlineWork("Mission: Yozakura Family", "مانجا", "أكشن • كوميديا", "طالب يدخل عائلة تعمل في عالم التجسس.", "MANGA Plus", "https://mangaplus.shueisha.co.jp/"),
        OnlineWork("The Beginning After the End", "مانهوا", "فانتازيا • تناسخ", "ملك سابق يبدأ حياة جديدة في عالم سحري.", "Tapas", "https://tapas.io/series/TBATE"),
        OnlineWork("Lore Olympus", "مانهوا", "فانتازيا • دراما", "إعادة تخيّل معاصرة للأساطير اليونانية.", "WEBTOON", "https://www.webtoons.com/en/romance/lore-olympus/list?title_no=1320"),
        OnlineWork("The Advanced Player of the Tutorial Tower", "مانهوا", "أكشن • أبراج", "مقاتل يخرج من برج تدريبي بعد سنوات طويلة.", "WEBTOON", "https://www.webtoons.com/en/action"),
        OnlineWork("Hardcore Leveling Warrior", "مانهوا", "أكشن • ألعاب", "لاعب قوي يحاول استعادة مكانته داخل لعبة.", "WEBTOON", "https://www.webtoons.com/en/action/hardcore-leveling-warrior/list?title_no=1221"),
        OnlineWork("Noblesse", "مانهوا", "أكشن • خارق للطبيعة", "مصاص دماء نبيل يستيقظ في العالم الحديث.", "WEBTOON", "https://www.webtoons.com/en/action/noblesse/list?title_no=87"),
        OnlineWork("UnOrdinary", "مانهوا", "أكشن • مدرسي", "مدرسة حيث تحدد القدرات مكانة الطلاب.", "WEBTOON", "https://www.webtoons.com/en/super-hero/unordinary/list?title_no=679"),
        OnlineWork("The Boxer", "مانهوا", "رياضة • دراما", "رحلة ملاكم موهوب ومدرب يبحث عن معنى الفوز.", "WEBTOON", "https://www.webtoons.com/en/sports/the-boxer/list?title_no=2027"),
        OnlineWork("Purple Hyacinth", "مانهوا", "غموض • تحقيق", "محققة تتعاون مع شخص خطير لكشف المؤامرات.", "WEBTOON", "https://www.webtoons.com/en/mystery/purple-hyacinth/list?title_no=1621"),
        OnlineWork("The Remarried Empress", "مانهوا", "دراما • فانتازيا", "إمبراطورة تعيد بناء حياتها بعد خيانة سياسية.", "WEBTOON", "https://www.webtoons.com/en/fantasy/the-remarried-empress/list?title_no=2135"),
        OnlineWork("The Kiss Bet", "مانهوا", "مدرسي • كوميديا", "طالبة تواجه مواقف محرجة في علاقاتها الاجتماعية.", "WEBTOON", "https://www.webtoons.com/en/romance/the-kiss-bet/list?title_no=1617"),
        // Expanded catalog: searchable entries link to a source index; availability varies by region and rights.
        OnlineWork("Naruto", "مانجا", "نينجا • أكشن", "ابحث عن Naruto في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Naruto"),
        OnlineWork("Bleach", "مانجا", "أكشن • خارق للطبيعة", "ابحث عن Bleach في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Bleach"),
        OnlineWork("Death Note", "مانجا", "غموض • نفسي", "ابحث عن Death Note في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Death%20Note"),
        OnlineWork("Fullmetal Alchemist", "مانجا", "فانتازيا • مغامرات", "ابحث عن Fullmetal Alchemist في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Fullmetal%20Alchemist"),
        OnlineWork("Hunter x Hunter", "مانجا", "مغامرات • أكشن", "ابحث عن Hunter x Hunter في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Hunter%20x%20Hunter"),
        OnlineWork("Berserk", "مانجا", "فانتازيا مظلمة", "ابحث عن Berserk في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Berserk"),
        OnlineWork("Vinland Saga", "مانجا", "تاريخي • مغامرات", "ابحث عن Vinland Saga في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Vinland%20Saga"),
        OnlineWork("Kingdom", "مانجا", "تاريخي • حروب", "ابحث عن Kingdom في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Kingdom"),
        OnlineWork("Tokyo Ghoul", "مانجا", "رعب • أكشن", "ابحث عن Tokyo Ghoul في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Tokyo%20Ghoul"),
        OnlineWork("Attack on Titan", "مانجا", "أكشن • غموض", "ابحث عن Attack on Titan في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Attack%20on%20Titan"),
        OnlineWork("Haikyu!!", "مانجا", "رياضة • مدرسي", "ابحث عن Haikyu!! في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Haikyu%21%21"),
        OnlineWork("Slam Dunk", "مانجا", "رياضة • كوميديا", "ابحث عن Slam Dunk في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Slam%20Dunk"),
        OnlineWork("Kagurabachi", "مانجا", "أكشن • فانتازيا", "ابحث عن Kagurabachi في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Kagurabachi"),
        OnlineWork("The Apothecary Diaries", "مانجا", "غموض • تاريخي", "ابحث عن The Apothecary Diaries في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Apothecary%20Diaries"),
        OnlineWork("Frieren: Beyond Journey’s End", "مانجا", "فانتازيا • مغامرات", "ابحث عن Frieren: Beyond Journey’s End في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Frieren%3A%20Beyond%20Journey%E2%80%99s%20End"),
        OnlineWork("Dr. Stone", "مانجا", "خيال علمي • مغامرات", "ابحث عن Dr. Stone في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Dr.%20Stone"),
        OnlineWork("Fire Force", "مانجا", "أكشن • فانتازيا", "ابحث عن Fire Force في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Fire%20Force"),
        OnlineWork("Soul Eater", "مانجا", "أكشن • فانتازيا", "ابحث عن Soul Eater في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Soul%20Eater"),
        OnlineWork("Mob Psycho 100", "مانجا", "كوميديا • قوى خارقة", "ابحث عن Mob Psycho 100 في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Mob%20Psycho%20100"),
        OnlineWork("One-Punch Man", "مانجا", "أبطال • كوميديا", "ابحث عن One-Punch Man في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=One-Punch%20Man"),
        OnlineWork("The Promised Neverland", "مانجا", "غموض • إثارة", "ابحث عن The Promised Neverland في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Promised%20Neverland"),
        OnlineWork("D.Gray-man", "مانجا", "أكشن • فانتازيا", "ابحث عن D.Gray-man في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=D.Gray-man"),
        OnlineWork("Assassination Classroom", "مانجا", "مدرسي • كوميديا", "ابحث عن Assassination Classroom في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Assassination%20Classroom"),
        OnlineWork("Komi Can’t Communicate", "مانجا", "مدرسي • كوميديا", "ابحث عن Komi Can’t Communicate في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Komi%20Can%E2%80%99t%20Communicate"),
        OnlineWork("Kuroko’s Basketball", "مانجا", "رياضة • مدرسي", "ابحث عن Kuroko’s Basketball في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Kuroko%E2%80%99s%20Basketball"),
        OnlineWork("Blue Lock", "مانجا", "رياضة • تنافس", "ابحث عن Blue Lock في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Blue%20Lock"),
        OnlineWork("Ao Ashi", "مانجا", "رياضة • دراما", "ابحث عن Ao Ashi في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Ao%20Ashi"),
        OnlineWork("Yona of the Dawn", "مانجا", "فانتازيا • مغامرات", "ابحث عن Yona of the Dawn في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Yona%20of%20the%20Dawn"),
        OnlineWork("Nana", "مانجا", "دراما • موسيقى", "ابحث عن Nana في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Nana"),
        OnlineWork("Fruits Basket", "مانجا", "دراما • فانتازيا", "ابحث عن Fruits Basket في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Fruits%20Basket"),
        OnlineWork("Sailor Moon", "مانجا", "فانتازيا • مغامرات", "ابحث عن Sailor Moon في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Sailor%20Moon"),
        OnlineWork("Cardcaptor Sakura", "مانجا", "فانتازيا • مدرسي", "ابحث عن Cardcaptor Sakura في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Cardcaptor%20Sakura"),
        OnlineWork("Inuyasha", "مانجا", "فانتازيا • مغامرات", "ابحث عن Inuyasha في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Inuyasha"),
        OnlineWork("Rurouni Kenshin", "مانجا", "تاريخي • أكشن", "ابحث عن Rurouni Kenshin في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Rurouni%20Kenshin"),
        OnlineWork("JoJo’s Bizarre Adventure", "مانجا", "أكشن • مغامرات", "ابحث عن JoJo’s Bizarre Adventure في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=JoJo%E2%80%99s%20Bizarre%20Adventure"),
        OnlineWork("Gintama", "مانجا", "كوميديا • أكشن", "ابحث عن Gintama في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Gintama"),
        OnlineWork("Detective Conan", "مانجا", "غموض • تحقيق", "ابحث عن Detective Conan في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Detective%20Conan"),
        OnlineWork("The Seven Deadly Sins", "مانجا", "فانتازيا • أكشن", "ابحث عن The Seven Deadly Sins في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Seven%20Deadly%20Sins"),
        OnlineWork("Fairy Tail", "مانجا", "فانتازيا • مغامرات", "ابحث عن Fairy Tail في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Fairy%20Tail"),
        OnlineWork("Magi", "مانجا", "فانتازيا • مغامرات", "ابحث عن Magi في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Magi"),
        OnlineWork("World Trigger", "مانجا", "خيال علمي • أكشن", "ابحث عن World Trigger في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=World%20Trigger"),
        OnlineWork("Black Butler", "مانجا", "غموض • فانتازيا", "ابحث عن Black Butler في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Black%20Butler"),
        OnlineWork("Re:Zero — manga", "مانجا", "فانتازيا • دراما", "ابحث عن Re:Zero — manga في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Re%3AZero%20%E2%80%94%20manga"),
        OnlineWork("That Time I Got Reincarnated as a Slime", "مانجا", "فانتازيا • تناسخ", "ابحث عن That Time I Got Reincarnated as a Slime في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=That%20Time%20I%20Got%20Reincarnated%20as%20a%20Slime"),
        OnlineWork("Overlord", "مانجا", "فانتازيا • ألعاب", "ابحث عن Overlord في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Overlord"),
        OnlineWork("Solo Leveling", "مانهوا", "أكشن • أبراج", "ابحث عن Solo Leveling في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Solo%20Leveling"),
        OnlineWork("The Legend of the Northern Blade", "مانهوا", "فنون قتالية • أكشن", "ابحث عن The Legend of the Northern Blade في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Legend%20of%20the%20Northern%20Blade"),
        OnlineWork("Return of the Mount Hua Sect", "مانهوا", "فنون قتالية • كوميديا", "ابحث عن Return of the Mount Hua Sect في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Return%20of%20the%20Mount%20Hua%20Sect"),
        OnlineWork("Nano Machine", "مانهوا", "فنون قتالية • خيال علمي", "ابحث عن Nano Machine في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Nano%20Machine"),
        OnlineWork("Murim Login", "مانهوا", "فنون قتالية • ألعاب", "ابحث عن Murim Login في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Murim%20Login"),
        OnlineWork("The Greatest Estate Developer", "مانهوا", "فانتازيا • كوميديا", "ابحث عن The Greatest Estate Developer في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Greatest%20Estate%20Developer"),
        OnlineWork("Revenge of the Iron-Blooded Sword Hound", "مانهوا", "فانتازيا • انتقام", "ابحث عن Revenge of the Iron-Blooded Sword Hound في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Revenge%20of%20the%20Iron-Blooded%20Sword%20Hound"),
        OnlineWork("Doom Breaker", "مانهوا", "أكشن • فانتازيا", "ابحث عن Doom Breaker في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Doom%20Breaker"),
        OnlineWork("The World After the Fall", "مانهوا", "أكشن • فانتازيا", "ابحث عن The World After the Fall في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20World%20After%20the%20Fall"),
        OnlineWork("SSS-Class Revival Hunter", "مانهوا", "أبراج • فانتازيا", "ابحث عن SSS-Class Revival Hunter في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=SSS-Class%20Revival%20Hunter"),
        OnlineWork("Return of the Blossoming Blade", "مانهوا", "فنون قتالية • مغامرات", "ابحث عن Return of the Blossoming Blade في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Return%20of%20the%20Blossoming%20Blade"),
        OnlineWork("The Player Who Returned 10,000 Years Later", "مانهوا", "أكشن • فانتازيا", "ابحث عن The Player Who Returned 10,000 Years Later في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Player%20Who%20Returned%2010%2C000%20Years%20Later"),
        OnlineWork("The S-Classes That I Raised", "مانهوا", "فانتازيا • أبراج", "ابحث عن The S-Classes That I Raised في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20S-Classes%20That%20I%20Raised"),
        OnlineWork("Pick Me Up, Infinite Gacha", "مانهوا", "ألعاب • فانتازيا", "ابحث عن Pick Me Up, Infinite Gacha في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Pick%20Me%20Up%2C%20Infinite%20Gacha"),
        OnlineWork("The Player Hides His Past", "مانهوا", "أكشن • ألعاب", "ابحث عن The Player Hides His Past في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Player%20Hides%20His%20Past"),
        OnlineWork("The Novel’s Extra", "مانهوا", "فانتازيا • أكاديمية", "ابحث عن The Novel’s Extra في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Novel%E2%80%99s%20Extra"),
        OnlineWork("The Max-Level Player’s 100th Regression", "مانهوا", "أكشن • أبراج", "ابحث عن The Max-Level Player’s 100th Regression في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Max-Level%20Player%E2%80%99s%20100th%20Regression"),
        OnlineWork("I’m the Queen in This Life", "مانهوا", "دراما • تاريخي", "ابحث عن I’m the Queen in This Life في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=I%E2%80%99m%20the%20Queen%20in%20This%20Life"),
        OnlineWork("Who Made Me a Princess", "مانهوا", "فانتازيا • دراما", "ابحث عن Who Made Me a Princess في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Who%20Made%20Me%20a%20Princess"),
        OnlineWork("Villains Are Destined to Die", "مانهوا", "فانتازيا • دراما", "ابحث عن Villains Are Destined to Die في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Villains%20Are%20Destined%20to%20Die"),
        OnlineWork("The Villainess Turns the Hourglass", "مانهوا", "دراما • انتقام", "ابحث عن The Villainess Turns the Hourglass في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Villainess%20Turns%20the%20Hourglass"),
        OnlineWork("A Stepmother’s Märchen", "مانهوا", "دراما • تاريخي", "ابحث عن A Stepmother’s Märchen في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=A%20Stepmother%E2%80%99s%20M%C3%A4rchen"),
        OnlineWork("Secret Lady", "مانهوا", "رومانسية • فانتازيا", "ابحث عن Secret Lady في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Secret%20Lady"),
        OnlineWork("I Shall Master This Family", "مانهوا", "دراما • تاريخي", "ابحث عن I Shall Master This Family في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=I%20Shall%20Master%20This%20Family"),
        OnlineWork("The Perks of Being an S-Class Heroine", "مانهوا", "فانتازيا • مغامرات", "ابحث عن The Perks of Being an S-Class Heroine في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Perks%20of%20Being%20an%20S-Class%20Heroine"),
        OnlineWork("The Fantasie of a Stepmother", "مانهوا", "دراما • فانتازيا", "ابحث عن The Fantasie of a Stepmother في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Fantasie%20of%20a%20Stepmother"),
        OnlineWork("The Broken Ring: This Marriage Will Fail Anyway", "مانهوا", "دراما • تاريخي", "ابحث عن The Broken Ring: This Marriage Will Fail Anyway في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Broken%20Ring%3A%20This%20Marriage%20Will%20Fail%20Anyway"),
        OnlineWork("A Returner’s Magic Should Be Special", "مانهوا", "فانتازيا • أكاديمية", "ابحث عن A Returner’s Magic Should Be Special في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=A%20Returner%E2%80%99s%20Magic%20Should%20Be%20Special"),
        OnlineWork("The Great Mage Returns After 4000 Years", "مانهوا", "فانتازيا • سحر", "ابحث عن The Great Mage Returns After 4000 Years في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Great%20Mage%20Returns%20After%204000%20Years"),
        OnlineWork("Limit Breaker", "مانهوا", "أكشن • أبراج", "ابحث عن Limit Breaker في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Limit%20Breaker"),
        OnlineWork("Leviathan", "مانهوا", "خيال علمي • بقاء", "ابحث عن Leviathan في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Leviathan"),
        OnlineWork("The First Hunter", "مانهوا", "أكشن • وحوش", "ابحث عن The First Hunter في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20First%20Hunter"),
        OnlineWork("Tomb Raider King", "مانهوا", "مغامرات • آثار", "ابحث عن Tomb Raider King في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Tomb%20Raider%20King"),
        OnlineWork("The Player of the Tutorial Tower", "مانهوا", "أكشن • أبراج", "ابحث عن The Player of the Tutorial Tower في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Player%20of%20the%20Tutorial%20Tower"),
        OnlineWork("The Return of the Crazy Demon", "مانهوا", "فنون قتالية • كوميديا", "ابحث عن The Return of the Crazy Demon في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Return%20of%20the%20Crazy%20Demon"),
        OnlineWork("Peerless Dad", "مانهوا", "فنون قتالية • دراما", "ابحث عن Peerless Dad في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Peerless%20Dad"),
        OnlineWork("Gosu", "مانهوا", "فنون قتالية • أكشن", "ابحث عن Gosu في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Gosu"),
        OnlineWork("The Breaker", "مانهوا", "فنون قتالية • مدرسي", "ابحث عن The Breaker في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Breaker"),
        OnlineWork("The Breaker: New Waves", "مانهوا", "فنون قتالية • أكشن", "ابحث عن The Breaker: New Waves في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Breaker%3A%20New%20Waves"),
        OnlineWork("Wind Breaker", "مانهوا", "رياضة • دراما", "ابحث عن Wind Breaker في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Wind%20Breaker"),
        OnlineWork("Study Group", "مانهوا", "مدرسي • أكشن", "ابحث عن Study Group في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Study%20Group"),
        OnlineWork("弱", "مانهوا", "مدرسي • أكشن", "ابحث عن 弱 في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=%E5%BC%B1"),
        OnlineWork("Questism", "مانهوا", "مدرسي • أكشن", "ابحث عن Questism في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Questism"),
        OnlineWork("Viral Hit", "مانهوا", "أكشن • مدرسي", "ابحث عن Viral Hit في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Viral%20Hit"),
        OnlineWork("Manager Kim", "مانهوا", "أكشن • جريمة", "ابحث عن Manager Kim في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Manager%20Kim"),
        OnlineWork("The World Is Money and Power", "مانهوا", "مدرسي • دراما", "ابحث عن The World Is Money and Power في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20World%20Is%20Money%20and%20Power"),
        OnlineWork("Girls of the Wild’s", "مانهوا", "رياضة • أكشن", "ابحث عن Girls of the Wild’s في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Girls%20of%20the%20Wild%E2%80%99s"),
        OnlineWork("Age Matters", "مانهوا", "رومانسية • دراما", "ابحث عن Age Matters في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Age%20Matters"),
        OnlineWork("Seasons of Blossom", "مانهوا", "مدرسي • دراما", "ابحث عن Seasons of Blossom في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Seasons%20of%20Blossom"),
        OnlineWork("True Beauty", "مانهوا", "دراما • مدرسي", "ابحث عن True Beauty في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=True%20Beauty"),
        OnlineWork("Cheese in the Trap", "مانهوا", "دراما • جامعي", "ابحث عن Cheese in the Trap في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Cheese%20in%20the%20Trap"),
        OnlineWork("My ID Is Gangnam Beauty", "مانهوا", "دراما • جامعي", "ابحث عن My ID Is Gangnam Beauty في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=My%20ID%20Is%20Gangnam%20Beauty"),
        OnlineWork("The Makeup Remover", "مانهوا", "دراما • اجتماعي", "ابحث عن The Makeup Remover في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Makeup%20Remover"),
        OnlineWork("A Good Day to Be a Dog", "مانهوا", "رومانسية • فانتازيا", "ابحث عن A Good Day to Be a Dog في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=A%20Good%20Day%20to%20Be%20a%20Dog"),
        OnlineWork("See You in My 19th Life", "مانهوا", "رومانسية • فانتازيا", "ابحث عن See You in My 19th Life في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=See%20You%20in%20My%2019th%20Life"),
        OnlineWork("The Sound of Magic", "مانهوا", "دراما • فانتازيا", "ابحث عن The Sound of Magic في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Sound%20of%20Magic"),
        OnlineWork("Bastard", "مانهوا", "إثارة • غموض", "ابحث عن Bastard في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Bastard"),
        OnlineWork("Sweet Home", "مانهوا", "رعب • بقاء", "ابحث عن Sweet Home في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Sweet%20Home"),
        OnlineWork("Pigpen", "مانهوا", "غموض • إثارة", "ابحث عن Pigpen في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Pigpen"),
        OnlineWork("Shotgun Boy", "مانهوا", "رعب • إثارة", "ابحث عن Shotgun Boy في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Shotgun%20Boy"),
        OnlineWork("The Horizon", "مانهوا", "دراما • بقاء", "ابحث عن The Horizon في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Horizon"),
        OnlineWork("The Build Up", "مانهوا", "رياضة • كرة قدم", "ابحث عن The Build Up في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Build%20Up"),
        OnlineWork("The Skeleton Soldier Failed to Defend the Dungeon", "مانهوا", "فانتازيا • أبراج", "ابحث عن The Skeleton Soldier Failed to Defend the Dungeon في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Skeleton%20Soldier%20Failed%20to%20Defend%20the%20Dungeon"),
        OnlineWork("Dungeon Odyssey", "مانهوا", "فانتازيا • أبراج", "ابحث عن Dungeon Odyssey في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Dungeon%20Odyssey"),
        OnlineWork("I Became the Tyrant of a Defense Game", "مانهوا", "ألعاب • فانتازيا", "ابحث عن I Became the Tyrant of a Defense Game في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=I%20Became%20the%20Tyrant%20of%20a%20Defense%20Game"),
        OnlineWork("The Heavenly Demon Can’t Live a Normal Life", "مانهوا", "فانتازيا • أكشن", "ابحث عن The Heavenly Demon Can’t Live a Normal Life في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Heavenly%20Demon%20Can%E2%80%99t%20Live%20a%20Normal%20Life"),
        OnlineWork("Reincarnation of the Suicidal Battle God", "مانهوا", "فانتازيا • أكشن", "ابحث عن Reincarnation of the Suicidal Battle God في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Reincarnation%20of%20the%20Suicidal%20Battle%20God"),
        OnlineWork("Player", "مانهوا", "أكشن • فانتازيا", "ابحث عن Player في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Player"),
        OnlineWork("The Druid of Seoul Station", "مانهوا", "فانتازيا • وحوش", "ابحث عن The Druid of Seoul Station في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Druid%20of%20Seoul%20Station"),
        OnlineWork("The Lone Necromancer", "مانهوا", "أكشن • بقاء", "ابحث عن The Lone Necromancer في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Lone%20Necromancer"),
        OnlineWork("The Live", "مانهوا", "أكشن • بقاء", "ابحث عن The Live في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Live"),
        OnlineWork("The Tutorial Is Too Hard", "مانهوا", "أكشن • أبراج", "ابحث عن The Tutorial Is Too Hard في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Tutorial%20Is%20Too%20Hard"),
        OnlineWork("Return to Player", "مانهوا", "أكشن • ألعاب", "ابحث عن Return to Player في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Return%20to%20Player"),
        OnlineWork("Leveling with the Gods", "مانهوا", "أكشن • أساطير", "ابحث عن Leveling with the Gods في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Leveling%20with%20the%20Gods"),
        OnlineWork("The Divine Twilight’s Return", "مانهوا", "فانتازيا • أكشن", "ابحث عن The Divine Twilight’s Return في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Divine%20Twilight%E2%80%99s%20Return"),
        OnlineWork("The Regressed Son of a Duke Is an Assassin", "مانهوا", "فانتازيا • انتقام", "ابحث عن The Regressed Son of a Duke Is an Assassin في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Regressed%20Son%20of%20a%20Duke%20Is%20an%20Assassin"),
        OnlineWork("Academy’s Genius Swordmaster", "مانهوا", "أكشن • أكاديمية", "ابحث عن Academy’s Genius Swordmaster في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Academy%E2%80%99s%20Genius%20Swordmaster"),
        OnlineWork("The Extra’s Academy Survival Guide", "مانهوا", "أكاديمية • فانتازيا", "ابحث عن The Extra’s Academy Survival Guide في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Extra%E2%80%99s%20Academy%20Survival%20Guide"),
        OnlineWork("I Killed an Academy Player", "مانهوا", "أكاديمية • فانتازيا", "ابحث عن I Killed an Academy Player في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=I%20Killed%20an%20Academy%20Player"),
        OnlineWork("The Demon Prince Goes to the Academy", "مانهوا", "أكاديمية • فانتازيا", "ابحث عن The Demon Prince Goes to the Academy في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Demon%20Prince%20Goes%20to%20the%20Academy"),
        OnlineWork("The Archmage Returns After 4000 Years", "مانهوا", "فانتازيا • سحر", "ابحث عن The Archmage Returns After 4000 Years في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Archmage%20Returns%20After%204000%20Years"),
        OnlineWork("Player Who Can’t Level Up", "مانهوا", "أكشن • أبراج", "ابحث عن Player Who Can’t Level Up في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Player%20Who%20Can%E2%80%99t%20Level%20Up"),
        OnlineWork("The Return of the Disaster-Class Hero", "مانهوا", "أكشن • فانتازيا", "ابحث عن The Return of the Disaster-Class Hero في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Return%20of%20the%20Disaster-Class%20Hero"),
        OnlineWork("The Wailing Perversion", "مانهوا", "فانتازيا • أكشن", "ابحث عن The Wailing Perversion في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Wailing%20Perversion"),
        OnlineWork("The Heavenly Path Is Not Obstructed", "مانهوا", "فنون قتالية • فانتازيا", "ابحث عن The Heavenly Path Is Not Obstructed في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20Heavenly%20Path%20Is%20Not%20Obstructed"),
        OnlineWork("I Am the Fated Villain", "مانهوا", "فانتازيا • انتقام", "ابحث عن I Am the Fated Villain في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=I%20Am%20the%20Fated%20Villain"),
        OnlineWork("Magic Emperor", "مانهوا", "فنون قتالية • فانتازيا", "ابحث عن Magic Emperor في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Magic%20Emperor"),
        OnlineWork("Martial Peak", "مانهوا", "فنون قتالية • فانتازيا", "ابحث عن Martial Peak في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Martial%20Peak"),
        OnlineWork("Apotheosis", "مانهوا", "فنون قتالية • فانتازيا", "ابحث عن Apotheosis في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Apotheosis"),
        OnlineWork("Battle Through the Heavens", "مانهوا", "فانتازيا • فنون قتالية", "ابحث عن Battle Through the Heavens في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Battle%20Through%20the%20Heavens"),
        OnlineWork("Tales of Demons and Gods", "مانهوا", "فانتازيا • تناسخ", "ابحث عن Tales of Demons and Gods في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Tales%20of%20Demons%20and%20Gods"),
        OnlineWork("The King’s Avatar", "مانهوا", "ألعاب • رياضة", "ابحث عن The King’s Avatar في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=The%20King%E2%80%99s%20Avatar"),
        OnlineWork("Release That Witch", "مانهوا", "فانتازيا • ممالك", "ابحث عن Release That Witch في فهرس المصدر، وتختلف الفصول واللغات المتاحة حسب الناشر والمنطقة.", "MangaDex — فهرس بحث", "https://mangadex.org/titles?q=Release%20That%20Witch"),
        OnlineWork("MangaDex — اكتشف المزيد", "مانجا", "فهرس • اكتشاف", "افتح الفهرس للبحث عن عناوين إضافية واللغات المتاحة. توفر الفصول يعتمد على الترخيص وسياسات المصدر.", "MangaDex", "https://mangadex.org/"),
        OnlineWork("WEBTOON — اكتشف المزيد", "مانهوا", "فهرس • اكتشاف", "تصفح أعمالًا إضافية من ناشر الويب تون مباشرة.", "WEBTOON", "https://www.webtoons.com/")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("alam_al_manga", MODE_PRIVATE)
        ChapterScanScheduler.ensureScheduled(this)
        loadCachedDiscoveredWorks()
        favorites.addAll(prefs.getStringSet("favorites", emptySet()) ?: emptySet())
        downloads.addAll(prefs.getStringSet("downloads", emptySet()) ?: emptySet())
        readerFontSize = prefs.getInt("reader_font", 18).coerceIn(14, 28)
        sepiaReader = prefs.getBoolean("reader_sepia", false)
        val savedHistory = prefs.getString("history", "[]") ?: "[]"
        try {
            val array = JSONArray(savedHistory)
            for (i in 0 until array.length()) {
                val item = array.optString(i)
                if (item.isNotBlank() && !history.contains(item)) history.add(item)
            }
        } catch (_: Exception) { /* Ignore damaged local history and start fresh. */ }
        applySystemColors()
        showHome()
    }

    private fun applySystemColors() {
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
    }

    private fun saveSets() {
        prefs.edit()
            .putStringSet("favorites", HashSet(favorites))
            .putStringSet("downloads", HashSet(downloads))
            .apply()
    }

    private fun saveHistory() {
        val array = JSONArray()
        history.take(30).forEach { array.put(it) }
        prefs.edit().putString("history", array.toString()).apply()
    }

    private fun keyFor(comic: Comic, chapterIndex: Int) = "${comic.title}|||$chapterIndex"

    private fun parseKey(key: String): Pair<Comic, Int>? {
        val bits = key.split("|||")
        if (bits.size != 2) return null
        val comic = comics.firstOrNull { it.title == bits[0] } ?: return null
        val index = bits[1].toIntOrNull() ?: return null
        if (index !in comic.chapters.indices) return null
        return comic to index
    }

    private fun recordRead(comic: Comic, index: Int) {
        val key = keyFor(comic, index)
        history.remove(key)
        history.add(0, key)
        while (history.size > 30) history.removeAt(history.lastIndex)
        saveHistory()
        prefs.edit().putString("last_read", key).apply()
    }

    private fun text(value: String, size: Float = 16f, color: Int = white, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(if (activeScreen == "reader" && sepiaReader && color == white) warmText else color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.RIGHT
            textDirection = View.TEXT_DIRECTION_RTL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(8, 7, 8, 7)
            setLineSpacing(3f, 1.05f)
        }
    }

    private fun button(value: String, enabled: Boolean = true, action: () -> Unit): Button {
        return Button(this).apply {
            text = value
            setTextColor(if (activeScreen == "reader" && sepiaReader) warmText else white)
            textSize = 12f
            isAllCaps = false
            setBackgroundColor(if (activeScreen == "reader" && sepiaReader) Color.rgb(226, 211, 181) else panel)
            isEnabled = enabled
            alpha = if (enabled) 1f else 0.45f
            setOnClickListener { action() }
        }
    }

    private fun addGap(height: Int = 8) {
        content.addView(View(this), LinearLayout.LayoutParams(1, height))
    }

    private fun makeRoot(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(if (activeScreen == "reader" && sepiaReader) warmBg else bg)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(14, 8, 14, 6)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 2, 0, 5)
        }
        header.addView(text("عالم المانجا", 24f, purple, true))
        header.addView(text(title, 13f, if (activeScreen == "reader" && sepiaReader) warmText else muted))
        root.addView(header)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, 0, 0, 4)
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = false
            clipToPadding = false
            addView(content)
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 6, 0, 0)
        }
        listOf("الرئيسية", "بحث", "المفضلة", "المحفوظ", "السجل").forEach { tab ->
            nav.addView(button(tab, action = {
                currentTab = tab
                when (tab) {
                    "الرئيسية" -> showHome()
                    "بحث" -> showSearch()
                    "المفضلة" -> showFavorites()
                    "المحفوظ" -> showDownloads()
                    else -> showHistory()
                }
            }), LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        setContentView(root)
    }

    private fun addSectionTitle(value: String) {
        content.addView(text(value, 19f, white, true))
    }

    private fun showHome() {
        activeScreen = "home"
        currentTab = "الرئيسية"
        makeRoot("مكتبة عربية خفيفة للمانجا والمانهوا")
        val cover = ImageView(this).apply {
            setImageResource(R.drawable.cover_poster)
            contentDescription = "غلاف عالم المانجا: بوروتو والمانهوا"
            scaleType = ImageView.ScaleType.CENTER_CROP
            adjustViewBounds = false
        }
        content.addView(cover, LinearLayout.LayoutParams(-1, (220 * resources.displayMetrics.density).toInt()))
        addGap(10)
        val banner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
            setBackgroundColor(panel)
        }
        banner.addView(text("مكتبتك تبدأ ببوروتو", 18f, purple, true))
        banner.addView(text("مانجا ومانهوا من منصات القراءة الرسمية، بالإضافة إلى قصص أصلية تعمل دون إنترنت.", 13f, muted))
        banner.addView(button("📖 افتح بوروتو: الجزء الثاني", action = { showOnlineWork(onlineWorks.first()) }))
        banner.addView(button("🌐 اقرأ بوروتو من المصدر الرسمي", action = { showOfficialReader(onlineWorks.first()) }))
        val resumeTarget = prefs.getString("last_read", null)?.let { parseKey(it) }
        if (resumeTarget != null) {
            banner.addView(button("▶ متابعة القراءة: ${resumeTarget.first.title}", action = {
                showReader(resumeTarget.first, resumeTarget.second)
            }))
        }
        content.addView(banner)
        content.addView(button("🆕 الفصول الجديدة المكتشفة", action = { showDiscoveredChapters() }))
        content.addView(button("🔄 فحص المصادر الآن", action = { runScanNow() }))
        addGap()
        content.addView(button("🌐 دليل المصادر الرسمية", action = { showSources() }))
        addGap()

        val categoryRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("الكل", "مانجا", "مانهوا").forEach { category ->
            categoryRow.addView(button(if (filter == category) "● $category" else category, action = {
                filter = category
                showHome()
            }), LinearLayout.LayoutParams(0, -2, 1f))
        }
        content.addView(categoryRow)
        addSectionTitle("مكتبة المانجا والمانهوا أونلاين")
        content.addView(text("الفصول والصور تفتح من موقع الناشر أو المنصة نفسها؛ لذلك يظل التوفر تابعًا لحسابك وبلدك وشروط المصدر.", 12f, muted))
        val onlineShown = allOnlineWorks().filter { filter == "الكل" || it.kind == filter }
        onlineShown.take(4).forEach { addOnlineWorkCard(content, it) }
        content.addView(button("عرض المكتبة الأونلاين كاملة (${onlineShown.size})", action = { showOnlineLibrary() }))
        addGap()
        addSectionTitle(if (filter == "الكل") "قصص أصلية مدمجة" else "${filter} مختارة من القصص الأصلية")
        comics.filter { filter == "الكل" || it.kind == filter }.forEach { addComicCard(it) }
        addGap()
        addSectionTitle("مميزات النسخة")
        content.addView(text("• يحفظ المفضلة والفصول المحفوظة وسجل القراءة على جهازك.\n• نصوص قصص تجريبية أصلية متاحة دون اتصال.\n• حجم خط القارئ ووضع القراءة الدافئ قابلان للتغيير.", 13f, muted))
        content.addView(text("ملاحظة: المكتبة الحالية نموذج قابل للتوسعة، وليست مكتبة الأعمال التجارية الكاملة. إضافة مانجا منشورة أو تنزيلها تحتاج مصدرًا مرخصًا وملفات متاحة قانونيًا.", 12f, muted))
    }

    private fun runScanNow() {
        val request = OneTimeWorkRequestBuilder<ChapterScanWorker>().build()
        WorkManager.getInstance(applicationContext).enqueue(request)
        Toast.makeText(this, "بدأ طلب فحص المصادر. ستظهر النتائج بعد انتهاء الاتصال.", Toast.LENGTH_LONG).show()
        showDiscoveredChapters()
    }

    private fun showDiscoveredChapters() {
        activeScreen = "discovered"
        currentTab = "الرئيسية"
        makeRoot("الفصول الجديدة المكتشفة")
        content.addView(text("يفحص التطبيق فهرس MangaDex كل ساعة أثناء عمل خدمة الجدولة. النتائج روابط وبيانات للفصول، وليست نسخًا من صفحاتها. قد لا يظهر كل إصدار جديد إذا لم يكن منشورًا في هذا الفهرس.", 13f, muted))
        addGap()
        val last = prefs.getString("scan_last_at", "لم يكتمل أي فحص بعد") ?: "لم يكتمل أي فحص بعد"
        content.addView(text("آخر فحص: $last", 12f, muted))
        val status = prefs.getString("scan_status", "لم يبدأ الفحص بعد") ?: "لم يبدأ الفحص بعد"
        content.addView(text("الحالة: $status", 12f, muted))
        content.addView(button("فحص الآن", action = { runScanNow() }))
        addGap()
        val raw = prefs.getString("discovered_chapters", "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            if (arr.length() == 0) {
                content.addView(text("لا توجد فصول مكتشفة بعد. شغّل الفحص واتركه ينتهي مع اتصال الإنترنت.", 15f, white, true))
            }
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val title = item.optString("title", "فصل جديد")
                val manga = item.optString("manga", "عمل غير معروف")
                val chapter = item.optString("chapter", "")
                val date = item.optString("date", "")
                val url = item.optString("url", "https://mangadex.org/")
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(12, 10, 12, 10)
                    setBackgroundColor(panel)
                }
                card.addView(text(manga, 16f, purple, true))
                card.addView(text(if (chapter.isBlank()) title else "الفصل $chapter — $title", 14f, white, true))
                card.addView(text(date, 12f, muted))
                card.addView(button("فتح الفصل في المصدر ↗", action = {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                }))
                content.addView(card)
                addGap()
            }
        } catch (_: Exception) {
            content.addView(text("تعذر قراءة سجل الفصول. اضغط فحص الآن لإعادة المحاولة.", 14f, muted))
        }
    }

    private fun addOnlineWorkCard(target: LinearLayout, work: OnlineWork, loadCover: Boolean = true) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(8, 8, 8, 8)
            setBackgroundColor(panel)
        }
        val cover = ImageView(this).apply {
            contentDescription = "غلاف ${work.title}"
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.rgb(43, 45, 63))
            setImageResource(R.drawable.cover_poster)
            tag = work.title
        }
        val density = resources.displayMetrics.density
        card.addView(cover, LinearLayout.LayoutParams((88 * density).toInt(), (126 * density).toInt()))
        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(8, 0, 0, 0)
        }
        info.addView(text(work.title, 16f, white, true))
        info.addView(text("${work.kind} • ${work.genre}", 11f, purple, true))
        info.addView(text(work.platform, 11f, muted))
        info.addView(button("التفاصيل والقراءة", action = { showOnlineWork(work) }))
        info.addView(button(if (favorites.contains(work.title)) "★ محفوظ" else "☆ المفضلة", action = {
            toggleOnlineFavorite(work)
            if (activeScreen == "favorites") showFavorites() else if (activeScreen == "online_detail") showOnlineWork(work) else showHome()
        }))
        card.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 5, 0, 5)
        target.addView(card, lp)
        if (loadCover) loadOnlineCover(work, cover)
    }

    private fun toggleOnlineFavorite(work: OnlineWork) {
        if (!favorites.add(work.title)) favorites.remove(work.title)
        saveSets()
        Toast.makeText(this, if (favorites.contains(work.title)) "أُضيف إلى المفضلة" else "أُزيل من المفضلة", Toast.LENGTH_SHORT).show()
    }

    private fun showOnlineLibrary() {
        activeScreen = "online_library"
        currentTab = "الرئيسية"
        makeRoot("مكتبة المانجا والمانهوا الأونلاين")
        content.addView(text("اختَر عملًا لعرض تفاصيله وفتح صفحة القراءة التابعة للناشر أو المنصة. قد تختلف الفصول المجانية المتاحة حسب المنطقة واللغة.", 13f, muted))
        val search = EditText(this).apply {
            hint = "ابحث عن مانجا أو مانهوا..."
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 15f
            setSingleLine(true)
            setPadding(12, 8, 12, 8)
            setBackgroundColor(panel)
        }
        content.addView(search, LinearLayout.LayoutParams(-1, -2))
        val categoryRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("الكل", "مانجا", "مانهوا").forEach { category ->
            categoryRow.addView(button(if (filter == category) "● $category" else category, action = {
                filter = category
                showOnlineLibrary()
            }), LinearLayout.LayoutParams(0, -2, 1f))
        }
        content.addView(categoryRow)
        val results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(results)
        fun renderResults(query: String) {
            results.removeAllViews()
            val normalized = query.trim().lowercase()
            val matches = allOnlineWorks().filter {
                (filter == "الكل" || it.kind == filter) &&
                    (normalized.isEmpty() || listOf(it.title, it.kind, it.genre, it.description, it.platform).any { field -> field.lowercase().contains(normalized) })
            }
            results.addView(text("النتائج: ${matches.size} عمل", 13f, muted, true))
            if (matches.isEmpty()) results.addView(text("مفيش نتائج. جرّب اسمًا تانيًا أو غيّر التصنيف.", 14f, white))
            matches.forEach { addOnlineWorkCard(results, it) }
        }
        renderResults("")
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = renderResults(s?.toString().orEmpty())
            override fun afterTextChanged(s: Editable?) = Unit
        })
        content.addView(button("🌍 اكتشف أعمالًا جديدة من الفهرس العالمي", action = { discoverFromMangaDex(search.text.toString().trim()) }))
        content.addView(button("📚 اكتشف الدفعة التالية من الأعمال", action = { discoverFromMangaDex("") }))
        content.addView(text("الاكتشاف يتابع صفحات الفهرس بين المرات بدل إعادة أول النتائج دائمًا. الحد المتاح يظل تابعًا للمصدر.", 12f, muted))
        content.addView(button("فتح دليل جميع المصادر", action = { showSources() }))
    }

    private fun allOnlineWorks(): List<OnlineWork> = (onlineWorks + discoveredWorks).distinctBy { it.title.lowercase() }

    private fun loadCachedDiscoveredWorks() {
        try {
            val array = JSONArray(prefs.getString("discovered_works", "[]") ?: "[]")
            for (i in 0 until array.length()) {
                val o = array.optJSONObject(i) ?: continue
                val title = o.optString("title").trim()
                val url = o.optString("url").trim()
                if (title.isNotBlank() && url.startsWith("https://mangadex.org/")) {
                    discoveredWorks.add(OnlineWork(title, o.optString("kind", "مانجا"), "اكتشاف عالمي", "عمل مكتشف من فهرس MangaDex؛ توافر الفصول يعتمد على المصدر واللغة.", "MangaDex", url, o.optString("cover").takeIf { it.startsWith("https://") }))
                }
            }
        } catch (_: Exception) { }
    }

    private fun saveDiscoveredWorks() {
        val array = JSONArray()
        discoveredWorks.distinctBy { it.title.lowercase() }.take(5000).forEach { w ->
            val o = org.json.JSONObject()
            o.put("title", w.title); o.put("url", w.readUrl); o.put("kind", w.kind)
            w.coverUrl?.let { o.put("cover", it) }
            array.put(o)
        }
        prefs.edit().putString("discovered_works", array.toString()).apply()
    }

    private fun discoverFromMangaDex(query: String) {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val isSearch = query.isNotBlank()
        val startOffset = if (isSearch) 0 else prefs.getInt("mangadex_catalog_offset", 0).coerceIn(0, 9900)
        Toast.makeText(this, if (isSearch) "جاري البحث في الفهرس العالمي…" else "جاري اكتشاف دفعة جديدة من المكتبة…", Toast.LENGTH_SHORT).show()
        thread {
            try {
                val fetched = mutableListOf<OnlineWork>()
                val seenIds = mutableSetOf<String>()
                var lastOffset = startOffset
                var successfulPages = 0
                for (offset in startOffset until (startOffset + 1000).coerceAtMost(10000) step 100) {
                    val url = URL("https://api.mangadex.org/manga?limit=100&offset=$offset&includes[]=cover_art&order[followedCount]=desc" + if (isSearch) "&title=$encoded" else "")
                    val connection = (url.openConnection() as HttpURLConnection).apply {
                        connectTimeout = 12000; readTimeout = 15000
                        setRequestProperty("User-Agent", "AlamAlManga/1.2 (Android; paginated catalog discovery)")
                        setRequestProperty("Accept", "application/json")
                    }
                    val code = connection.responseCode
                    if (code !in 200..299) {
                        connection.disconnect()
                        if (successfulPages == 0) throw IllegalStateException("MangaDex HTTP $code")
                        break
                    }
                    val body = connection.inputStream.bufferedReader().use { it.readText() }
                    connection.disconnect()
                    val json = org.json.JSONObject(body)
                    val data = json.optJSONArray("data") ?: JSONArray()
                    if (data.length() == 0) break
                    successfulPages++
                    lastOffset = offset + data.length()
                    for (i in 0 until data.length()) {
                        val item = data.optJSONObject(i) ?: continue
                        val id = item.optString("id")
                        if (id.isBlank() || !seenIds.add(id)) continue
                        val attrs = item.optJSONObject("attributes") ?: continue
                        val titles = attrs.optJSONObject("title") ?: org.json.JSONObject()
                        var title = titles.optString("en").takeIf { it.isNotBlank() }
                        if (title == null) {
                            val keys = titles.keys()
                            while (keys.hasNext() && title == null) title = titles.optString(keys.next()).takeIf { it.isNotBlank() }
                        }
                        if (title.isNullOrBlank()) continue
                        val rels = item.optJSONArray("relationships") ?: JSONArray()
                        var cover: String? = null
                        for (j in 0 until rels.length()) {
                            val rel = rels.optJSONObject(j) ?: continue
                            if (rel.optString("type") == "cover_art") {
                                val fileName = rel.optJSONObject("attributes")?.optString("fileName")
                                if (!fileName.isNullOrBlank() && fileName != "null") cover = "https://uploads.mangadex.org/covers/$id/$fileName.256.jpg"
                            }
                        }
                        val originalLang = attrs.optString("originalLanguage")
                        val kind = when (originalLang) { "ko" -> "مانهوا"; "zh" -> "مانهوا/مانهوا صينية"; else -> "مانجا" }
                        fetched.add(OnlineWork(title, kind, "اكتشاف عالمي", "عنوان من فهرس MangaDex. الفصول والصور المتاحة تختلف حسب اللغة وحقوق النشر.", "MangaDex", "https://mangadex.org/title/$id", cover))
                    }
                    if (data.length() < 100 || offset >= 9900) break
                    Thread.sleep(300)
                }
                mainHandler.post {
                    val existing = allOnlineWorks().map { it.title.lowercase() }.toMutableSet()
                    var added = 0
                    fetched.forEach { if (existing.add(it.title.lowercase())) { discoveredWorks.add(it); added++ } }
                    if (!isSearch && successfulPages > 0) {
                        val nextOffset = if (lastOffset >= 10000) 0 else lastOffset
                        prefs.edit().putInt("mangadex_catalog_offset", nextOffset).apply()
                    }
                    saveDiscoveredWorks()
                    if (activeScreen == "online_library") showOnlineLibrary()
                    val next = prefs.getInt("mangadex_catalog_offset", 0)
                    Toast.makeText(this, "انتهى الاكتشاف. صفحات ناجحة: $successfulPages — عناوين جديدة: $added — إجمالي المكتبة: ${allOnlineWorks().size} — موضع الدفعة التالية: $next", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                mainHandler.post { Toast.makeText(this, "تعذر الاتصال بالفهرس الآن. جرّب لاحقًا أو افحص الإنترنت.", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun loadMangaDexChapters(work: OnlineWork) {
        val match = Regex("/title/([0-9a-fA-F-]{36})").find(work.readUrl)
        val mangaId = match?.groupValues?.getOrNull(1)
        if (mangaId.isNullOrBlank()) {
            Toast.makeText(this, "معرّف العمل غير متاح في رابط المصدر", Toast.LENGTH_SHORT).show()
            return
        }
        activeScreen = "mangadex_chapters"
        makeRoot("فصول ${work.title}")
        content.addView(text("الفصول التي يعرضها فهرس MangaDex فقط. قد تختلف اللغات والتوافر، والقراءة تفتح صفحة المصدر.", 13f, muted))
        content.addView(button("← العودة للعمل", action = { showOnlineWork(work) }))
        content.addView(text("جاري تحميل قائمة الفصول…", 14f, white))
        thread {
            try {
                val url = URL("https://api.mangadex.org/manga/$mangaId/feed?limit=100&offset=0&translatedLanguage[]=en&translatedLanguage[]=ar&order[chapter]=desc&order[readableAt]=desc")
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 12000; readTimeout = 15000
                    setRequestProperty("User-Agent", "AlamAlManga/1.2 (Android; chapter metadata)")
                    setRequestProperty("Accept", "application/json")
                }
                val code = connection.responseCode
                if (code !in 200..299) throw IllegalStateException("MangaDex HTTP $code")
                val json = org.json.JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
                connection.disconnect()
                val data = json.optJSONArray("data") ?: JSONArray()
                val chapters = mutableListOf<Pair<String, String>>()
                for (i in 0 until data.length()) {
                    val item = data.optJSONObject(i) ?: continue
                    val id = item.optString("id")
                    val attrs = item.optJSONObject("attributes") ?: continue
                    val number = attrs.optString("chapter").takeIf { it.isNotBlank() && it != "null" } ?: "؟"
                    val title = attrs.optString("title").takeIf { it.isNotBlank() && it != "null" }
                    val lang = attrs.optString("translatedLanguage")
                    val date = attrs.optString("readableAt").take(10)
                    val label = "الفصل $number${title?.let { " — $it" } ?: ""} • $lang${if (date.isNotBlank()) " • $date" else ""}"
                    if (id.isNotBlank()) chapters.add(label to "https://mangadex.org/chapter/$id")
                }
                mainHandler.post {
                    if (activeScreen != "mangadex_chapters") return@post
                    makeRoot("فصول ${work.title}")
                    content.addView(text("تم العثور على ${chapters.size} فصلًا ضمن أول 100 نتيجة باللغة الإنجليزية أو العربية. هذه بيانات فهرس وليست صفحات محفوظة.", 13f, muted))
                    content.addView(button("← العودة للعمل", action = { showOnlineWork(work) }))
                    if (chapters.isEmpty()) content.addView(text("لم يعرض الفهرس فصولًا بهذه اللغات. جرّب صفحة العمل الأصلية.", 14f, white))
                    chapters.forEach { (label, link) -> content.addView(button(label, action = { openExternal(link) })) }
                }
            } catch (_: Exception) {
                mainHandler.post {
                    if (activeScreen == "mangadex_chapters") {
                        makeRoot("فصول ${work.title}")
                        content.addView(text("تعذر تحميل قائمة الفصول الآن. جرّب فتح المصدر مباشرة.", 14f, muted))
                        content.addView(button("فتح صفحة العمل ↗", action = { openExternal(work.readUrl) }))
                        content.addView(button("← العودة للعمل", action = { showOnlineWork(work) }))
                    }
                }
            }
        }
    }

    private fun showOnlineWork(work: OnlineWork) {
        activeWebView?.stopLoading()
        activeWebView?.destroy()
        activeWebView = null
        activeScreen = "online_detail"
        activeOnlineWork = work
        currentTab = "الرئيسية"
        makeRoot(work.title)
        val cover = ImageView(this).apply {
            contentDescription = "غلاف ${work.title}"
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.rgb(34, 36, 52))
            setImageResource(R.drawable.cover_poster)
            tag = work.title
        }
        content.addView(cover, LinearLayout.LayoutParams(-1, (230 * resources.displayMetrics.density).toInt()))
        loadOnlineCover(work, cover)
        content.addView(text("${work.kind} • ${work.genre}", 14f, purple, true))
        content.addView(text(work.description, 15f, muted))
        content.addView(text("المصدر: ${work.platform}", 13f, white, true))
        content.addView(text("الفصول والصفحات تُحمّل مباشرة من المصدر؛ التطبيق لا يحتفظ بنسخ من الفصول التجارية. التوفر واللغة قد يختلفان حسب المنطقة.", 12f, muted))
        content.addView(button(if (favorites.contains(work.title)) "★ إزالة من المفضلة" else "☆ إضافة إلى المفضلة", action = {
            toggleOnlineFavorite(work)
            showOnlineWork(work)
        }))
        if (work.readUrl.contains("mangadex.org/title/")) {
            content.addView(button("📑 عرض الفصول المتاحة في الفهرس", action = { loadMangaDexChapters(work) }))
        }
        content.addView(button("📖 القراءة داخل التطبيق", action = { showOfficialReader(work) }))
        content.addView(button("فتح المصدر في المتصفح الخارجي ↗", action = { openExternal(work.readUrl) }))
        if (!work.fallbackUrl.isNullOrBlank()) {
            content.addView(button("مصدر رسمي بديل: VIZ ↗", action = { openExternal(work.fallbackUrl) }))
        }
        content.addView(text("ملاحظة: لو الصفحة لم تعمل داخل القارئ، استخدم زر المتصفح الخارجي أو التطبيق الرسمي للمنصة.", 12f, muted))
    }

    private fun showOfficialReader(work: OnlineWork) {
        activeScreen = "webreader"
        activeOnlineWork = work
        activeWebView?.stopLoading()
        activeWebView?.destroy()
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(8, 8, 8, 4)
            setBackgroundColor(bg)
        }
        root.addView(text(work.title, 18f, purple, true))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("← تفاصيل العمل", action = { showOnlineWork(work) }), LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(button("فتح في المتصفح ↗", action = { openExternal(work.readUrl) }), LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(actions)
        root.addView(text("المحتوى يأتي مباشرة من ${work.platform}، وقد يتطلب تسجيل الدخول أو التطبيق الرسمي.", 11f, muted))
        val webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            webViewClient = WebViewClient()
        }
        activeWebView = webView
        root.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        webView.loadUrl(work.readUrl)
    }

    private fun openExternal(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            Toast.makeText(this, "تعذر فتح الرابط على الجهاز", Toast.LENGTH_LONG).show()
        }
    }

    private fun loadOnlineCover(work: OnlineWork, imageView: ImageView) {
        val key = work.title
        imageView.tag = key
        remoteCoverCache[key]?.let { imageView.setImageBitmap(it); return }
        Thread({
            var bitmap: Bitmap? = null
            try {
                var imageUrl = work.coverUrl ?: remoteCoverUrlCache[key]
                if (imageUrl.isNullOrBlank()) {
                    imageUrl = extractOfficialPageImage(work.readUrl)
                    if (!imageUrl.isNullOrBlank()) remoteCoverUrlCache[key] = imageUrl
                }
                if (!imageUrl.isNullOrBlank()) {
                    val connection = (URL(imageUrl).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 7000
                        readTimeout = 9000
                        instanceFollowRedirects = true
                        setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) AlamAlManga/0.8.0")
                        setRequestProperty("Accept", "image/avif,image/webp,image/apng,image/*,*/*;q=0.8")
                    }
                    try {
                        if (connection.responseCode in 200..299) {
                            connection.inputStream.use { bitmap = BitmapFactory.decodeStream(it) }
                        }
                    } finally { connection.disconnect() }
                }
            } catch (_: Exception) { /* Poster remains as a visible fallback. */ }
            val loaded = bitmap
            if (loaded != null) remoteCoverCache[key] = loaded
            runOnUiThread {
                if (imageView.tag == key && loaded != null) imageView.setImageBitmap(loaded)
            }
        }, "alam-cover-${key.hashCode()}").start()
    }

    private fun extractOfficialPageImage(pageUrl: String): String? {
        var connection: HttpURLConnection? = null
        return try {
            val conn = (URL(pageUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 6000
                readTimeout = 7000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) AlamAlManga/0.8.0")
                setRequestProperty("Accept", "text/html,application/xhtml+xml")
            }
            connection = conn
            if (conn.responseCode !in 200..299) return null
            val html = conn.inputStream.bufferedReader().use { reader ->
                val out = StringBuilder()
                val chars = CharArray(4096)
                var total = 0
                while (total < 500_000) {
                    val read = reader.read(chars, 0, minOf(chars.size, 500_000 - total))
                    if (read <= 0) break
                    out.append(chars, 0, read)
                    total += read
                }
                out.toString()
            }
            val patterns = listOf(
                Regex("""(?is)<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']"""),
                Regex("""(?is)<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:image["']"""),
                Regex("""(?is)<meta[^>]+name=["']twitter:image["'][^>]+content=["']([^"']+)["']""")
            )
            val raw = patterns.firstNotNullOfOrNull { it.find(html)?.groupValues?.getOrNull(1) } ?: return null
            when {
                raw.startsWith("//") -> "https:$raw"
                raw.startsWith("http://") || raw.startsWith("https://") -> raw
                else -> null
            }
        } catch (_: Exception) {
            null
        } finally { connection?.disconnect() }
    }

    private fun showSources() {
        activeScreen = "sources"
        currentTab = "الرئيسية"
        makeRoot("دليل مصادر المانجا والمانهوا")
        content.addView(text("هذه روابط مباشرة إلى مواقع وفهارس رسمية. وجود الرابط لا يعني أن المحتوى متاح مجانًا في كل بلد أو أن التطبيق يستورد الفصول تلقائيًا.", 13f, muted))
        addGap()
        val sources = listOf(
            Triple("MANGA Plus", "قراءة رسمية", "https://mangaplus.shueisha.co.jp/"),
            Triple("VIZ Manga", "قراءة رسمية", "https://www.viz.com/manga"),
            Triple("WEBTOON", "مانهوا وويب تون", "https://www.webtoons.com/"),
            Triple("Tapas", "ويب تون وروايات مصورة", "https://tapas.io/"),
            Triple("K MANGA", "قراءة رسمية", "https://kmanga.kodansha.com/"),
            Triple("BOOK☆WALKER", "متجر كتب رقمية", "https://global.bookwalker.jp/"),
            Triple("MangaDex", "فهرس وبيانات عامة", "https://mangadex.org/"),
            Triple("AniList", "فهرس معلومات", "https://anilist.co/"),
            Triple("Kitsu", "فهرس معلومات", "https://kitsu.io/"),
            Triple("MyAnimeList Manga", "فهرس معلومات", "https://myanimelist.net/manga.php"),
            Triple("Anime-Planet", "فهرس وتوصيات", "https://www.anime-planet.com/manga"),
            Triple("MangaUpdates", "فهرس معلومات", "https://www.mangaupdates.com/"),
            Triple("MangaToon", "قراءة رسمية", "https://mangatoon.mobi/"),
            Triple("Manta", "قراءة رسمية", "https://manta.net/"),
            Triple("Tappytoon", "قراءة رسمية", "https://www.tappytoon.com/"),
            Triple("Lezhin Comics", "قراءة رسمية", "https://www.lezhinus.com/"),
            Triple("Comikey", "قراءة رسمية", "https://comikey.com/"),
            Triple("Manga UP!", "قراءة رسمية", "https://global.manga-up.com/"),
            Triple("Anime News Network", "أخبار المانجا والأنمي", "https://www.animenewsnetwork.com/"),
            Triple("GlobalComix", "منصة قصص مصورة رقمية", "https://globalcomix.com/"),
            Triple("MangaPlaza", "منصة مانجا مرخصة", "https://mangaplaza.com/"),
            Triple("Renta!", "متجر مانجا رقمية", "https://www.ebookrenta.com/"),
            Triple("Azuki", "منصة مانجا رقمية", "https://www.azuki.co/"),
            Triple("Omoi", "منصة مانجا رقمية", "https://www.omoi.com/"),
            Triple("Pocket Comics", "ويب تون ومانهوا", "https://www.comico.io/"),
            Triple("Piccoma", "منصة مانجا وويب تون", "https://piccoma.com/"),
            Triple("Manga Planet", "منصة مانجا مرخصة", "https://mangaplanet.com/"),
            Triple("Google Play Books", "متجر كتب رقمية", "https://play.google.com/store/books"),
            Triple("Apple Books", "متجر كتب رقمية", "https://books.apple.com/"),
            Triple("YouTube: أخبار المانجا", "بحث عن قنوات ومقاطع — ليس قائمة موثقة", "https://www.youtube.com/results?search_query=manga+news+official"),
            Triple("YouTube: مراجعات المانجا", "بحث عن صناع محتوى ومراجعات", "https://www.youtube.com/results?search_query=manga+reviews"),
            Triple("YouTube: مانجا بالعربي", "بحث عربي عن مراجعات وتوصيات", "https://www.youtube.com/results?search_query=%D9%85%D8%B1%D8%A7%D8%AC%D8%B9%D8%A7%D8%AA+%D9%85%D8%A7%D9%86%D8%AC%D8%A7"),
            Triple("TikTok: مانجا بالعربي", "بحث عن صناع محتوى — النتائج تتغير", "https://www.tiktok.com/search?q=%D9%85%D8%A7%D9%86%D8%AC%D8%A7"),
            Triple("TikTok: Manga recommendations", "بحث عن توصيات — النتائج تتغير", "https://www.tiktok.com/search?q=manga%20recommendations"),
            Triple("Reddit: Manga", "مجتمع نقاشات وتوصيات", "https://www.reddit.com/r/manga/"),
            Triple("Reddit: Manhwa", "مجتمع نقاشات وتوصيات", "https://www.reddit.com/r/manhwa/"),
            Triple("Reddit: MangaCollectors", "مجتمع جمع المانجا", "https://www.reddit.com/r/MangaCollectors/"),
            Triple("Jikan API", "واجهة بيانات غير رسمية لـ MyAnimeList — بيانات فقط", "https://jikan.moe/"),
            Triple("AniList GraphQL API", "واجهة بيانات وفهارس", "https://anilist.gitbook.io/anilist-apiv2-docs/"),
            Triple("MangaUpdates Search", "بحث عن بيانات الأعمال", "https://www.mangaupdates.com/series.html"),
            Triple("Crunchyroll News", "أخبار الأنمي والمانجا", "https://www.crunchyroll.com/news")
        )
        sources.forEach { (name, kind, url) ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(panel)
                setPadding(10, 8, 10, 8)
            }
            card.addView(text(name, 16f, white, true))
            card.addView(text(kind, 12f, muted))
            card.addView(button("فتح الموقع ↗", action = {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                catch (_: Exception) { Toast.makeText(this, "تعذر فتح الرابط", Toast.LENGTH_SHORT).show() }
            }))
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.setMargins(0, 5, 0, 5)
            content.addView(card, lp)
        }
        content.addView(text("عالم المانجا لا يستضيف صفحات الفصول المحمية. سنضيف التكامل الآلي فقط عندما تسمح واجهة المصدر وشروط استخدامه بذلك.", 12f, muted))
    }

    private fun addComicCard(comic: Comic) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(panel)
            setPadding(10, 7, 10, 7)
        }
        card.addView(text("📚  ${comic.title}", 18f, white, true))
        card.addView(text("${comic.kind}  •  ${comic.genre}  •  ${comic.chapters.size} فصول", 12f, purple, true))
        card.addView(text(comic.description, 13f, muted))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("اقرأ العمل", action = { showComic(comic) }), LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(button(if (favorites.contains(comic.title)) "★ محفوظ" else "☆ المفضلة", action = {
            toggleFavorite(comic)
            if (activeScreen == "favorites") showFavorites() else if (activeScreen == "detail") showComic(comic) else showHome()
        }), LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(actions)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 6, 0, 6)
        content.addView(card, lp)
    }

    private fun toggleFavorite(comic: Comic) {
        if (!favorites.add(comic.title)) favorites.remove(comic.title)
        saveSets()
        Toast.makeText(this, if (favorites.contains(comic.title)) "أُضيف إلى المفضلة" else "أُزيل من المفضلة", Toast.LENGTH_SHORT).show()
    }

    private fun showSearch() {
        activeScreen = "search"
        currentTab = "بحث"
        makeRoot("ابحث عن عنوان أو نوع أو تصنيف")
        val input = EditText(this).apply {
            hint = "مثال: فانتازيا، مانجا، رحلة الظلال"
            setHintTextColor(muted)
            setTextColor(white)
            textDirection = View.TEXT_DIRECTION_RTL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setSingleLine(true)
            setPadding(12, 10, 12, 10)
            setBackgroundColor(panel)
        }
        content.addView(input)
        val results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(results)
        fun refresh(query: String) {
            results.removeAllViews()
            val q = query.trim()
            val found = comics.filter {
                q.isEmpty() || it.title.contains(q, true) || it.kind.contains(q, true) ||
                    it.genre.contains(q, true) || it.description.contains(q, true)
            }
            val onlineFound = allOnlineWorks().filter {
                q.isEmpty() || it.title.contains(q, true) || it.kind.contains(q, true) ||
                    it.genre.contains(q, true) || it.description.contains(q, true) || it.platform.contains(q, true)
            }
            if (found.isEmpty() && onlineFound.isEmpty()) results.addView(text("مفيش نتائج مطابقة. جرّب كلمة تانية.", 14f, muted))
            else {
                if (onlineFound.isNotEmpty()) {
                    results.addView(text("من المكتبة الأونلاين", 17f, purple, true))
                    onlineFound.forEach { addOnlineWorkCard(results, it, loadCover = false) }
                }
                if (found.isNotEmpty()) {
                    results.addView(text("القصص الأصلية المدمجة", 17f, purple, true))
                    found.forEach { addComicCardTo(results, it) }
                }
            }
        }
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { refresh(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: Editable?) = Unit
        })
        refresh("")
    }

    private fun addComicCardTo(target: LinearLayout, comic: Comic) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(panel)
            setPadding(8, 5, 8, 5)
        }
        row.addView(text(comic.title, 17f, white, true))
        row.addView(text("${comic.kind} • ${comic.genre}", 12f, purple))
        row.addView(button("فتح العمل", action = { showComic(comic) }))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 5, 0, 5)
        target.addView(row, lp)
    }

    private fun showComic(comic: Comic) {
        activeScreen = "detail"
        activeComic = comic
        currentTab = ""
        makeRoot(comic.title)
        content.addView(text("${comic.kind} • ${comic.genre} • ${comic.chapters.size} فصول", 14f, purple, true))
        content.addView(text(comic.description, 15f, muted))
        content.addView(button(if (favorites.contains(comic.title)) "★ إزالة من المفضلة" else "☆ إضافة إلى المفضلة", action = {
            toggleFavorite(comic)
            showComic(comic)
        }))
        addSectionTitle("الفصول المتاحة دون إنترنت")
        comic.chapters.forEachIndexed { index, chapter ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(panel)
                setPadding(8, 4, 8, 4)
            }
            item.addView(text("${index + 1}. ${chapter.title}", 15f, white, true))
            val pageCount = pagesFor(comic, index).size
            val status = if (pageCount > 0) "$pageCount صفحة مستوردة ومحفوظة" else if (downloads.contains(keyFor(comic, index))) "✓ نص محفوظ على الجهاز" else "نص أصلي مدمج داخل التطبيق"
            item.addView(text(status, 12f, muted))
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            actions.addView(button("قراءة", action = { showReader(comic, index) }), LinearLayout.LayoutParams(0, -2, 1f))
            actions.addView(button(if (downloads.contains(keyFor(comic, index))) "إلغاء الحفظ" else "حفظ دون إنترنت", action = {
                toggleDownload(comic, index)
                showComic(comic)
            }), LinearLayout.LayoutParams(0, -2, 1f))
            item.addView(actions)
            item.addView(button("استيراد صفحات من جهازك", action = { importPages(comic, index) }))
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.setMargins(0, 5, 0, 5)
            content.addView(item, lp)
        }
        content.addView(button("مشاركة اسم العمل", action = { shareText("${comic.title} — عالم المانجا") }))
    }

    private fun toggleDownload(comic: Comic, index: Int) {
        val key = keyFor(comic, index)
        if (downloads.contains(key)) downloads.remove(key) else downloads.add(key)
        saveSets()
        Toast.makeText(this, if (downloads.contains(key)) "تم حفظ الفصل محليًا للرجوع إليه دون إنترنت" else "تم إلغاء الحفظ", Toast.LENGTH_SHORT).show()
    }

    private fun pagesPrefKey(comic: Comic, chapterIndex: Int): String =
        "pages_${Integer.toHexString(keyFor(comic, chapterIndex).hashCode())}"

    private fun pageDirectory(comic: Comic, chapterIndex: Int): File {
        val folderName = "chapter_${Integer.toHexString(keyFor(comic, chapterIndex).hashCode())}"
        return File(File(filesDir, "chapter_pages"), folderName)
    }

    private fun pagesFor(comic: Comic, chapterIndex: Int): List<String> {
        return try {
            val array = JSONArray(prefs.getString(pagesPrefKey(comic, chapterIndex), "[]") ?: "[]")
            (0 until array.length()).map { array.optString(it) }.filter { it.isNotBlank() }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun importPages(comic: Comic, chapterIndex: Int) {
        importTarget = comic to chapterIndex
        val picker = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            putExtra(Intent.EXTRA_TITLE, "اختر صفحات الفصل")
        }
        try {
            startActivityForResult(picker, importPagesRequestCode)
        } catch (_: Exception) {
            importTarget = null
            Toast.makeText(this, "تعذر فتح مدير الملفات على هذا الجهاز", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Android API; retained for compatibility with Android 6+")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != importPagesRequestCode || resultCode != RESULT_OK) return
        val target = importTarget ?: return
        importTarget = null
        val uris = mutableListOf<Uri>()
        val clip = data?.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) clip.getItemAt(i).uri?.let { uris.add(it) }
        } else {
            data?.data?.let { uris.add(it) }
        }
        if (uris.isEmpty()) {
            Toast.makeText(this, "لم يتم اختيار صور", Toast.LENGTH_SHORT).show()
            return
        }
        val (comic, chapterIndex) = target
        val folder = pageDirectory(comic, chapterIndex)
        if (!folder.exists()) folder.mkdirs()
        folder.listFiles()?.forEach { it.delete() }
        val copied = mutableListOf<String>()
        uris.take(50).forEachIndexed { index, uri ->
            val outputFile = File(folder, "page_${(index + 1).toString().padStart(3, '0')}.img")
            try {
                val input = contentResolver.openInputStream(uri)
                if (input != null) {
                    input.use { source ->
                        FileOutputStream(outputFile).use { output ->
                            val buffer = ByteArray(8192)
                            var total = 0L
                            while (true) {
                                val count = source.read(buffer)
                                if (count <= 0) break
                                total += count
                                if (total > 40L * 1024L * 1024L) throw IllegalStateException("الصورة أكبر من 40 ميجابايت")
                                output.write(buffer, 0, count)
                            }
                        }
                    }
                    if (outputFile.exists() && outputFile.length() > 0L) copied.add(outputFile.name)
                    else outputFile.delete()
                }
            } catch (_: Exception) {
                outputFile.delete()
            }
        }
        prefs.edit().putString(pagesPrefKey(comic, chapterIndex), JSONArray(copied).toString()).apply()
        Toast.makeText(
            this,
            if (copied.isEmpty()) "لم أستطع استيراد الصور. جرّب صورًا أصغر." else "تم حفظ ${copied.size} صفحة داخل التطبيق دون إنترنت",
            Toast.LENGTH_LONG
        ).show()
        showReader(comic, chapterIndex)
    }

    private fun addImportedPages(comic: Comic, chapterIndex: Int) {
        val names = pagesFor(comic, chapterIndex)
        if (names.isEmpty()) return
        val folder = pageDirectory(comic, chapterIndex)
        content.addView(text("صفحاتك المستوردة (${names.size})", 18f, purple, true))
        names.forEachIndexed { index, name ->
            val pageFile = File(folder, name)
            if (!pageFile.isFile) return@forEachIndexed
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(pageFile.absolutePath, options)
            val maxWidth = (resources.displayMetrics.widthPixels - (32 * resources.displayMetrics.density).toInt()).coerceAtLeast(320)
            var sample = 1
            while (options.outWidth / sample > maxWidth * 2 || options.outHeight / sample > 4096) sample *= 2
            val bitmap = BitmapFactory.decodeFile(pageFile.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
            if (bitmap != null) {
                content.addView(text("صفحة ${index + 1}", 12f, muted))
                val image = ImageView(this).apply {
                    setImageBitmap(bitmap)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    adjustViewBounds = true
                    contentDescription = "صفحة ${index + 1} من ${comic.title}"
                    setBackgroundColor(if (sepiaReader) warmPanel else panel)
                    setPadding(2, 2, 2, 2)
                }
                val lp = LinearLayout.LayoutParams(-1, -2)
                lp.setMargins(0, 3, 0, 10)
                content.addView(image, lp)
            }
        }
    }

    private fun showReader(comic: Comic, chapterIndex: Int) {
        if (chapterIndex !in comic.chapters.indices) return
        activeScreen = "reader"
        activeComic = comic
        activeChapterIndex = chapterIndex
        recordRead(comic, chapterIndex)
        val chapter = comic.chapters[chapterIndex]
        makeRoot("${comic.title} — ${chapter.title}")

        val readerTools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        readerTools.addView(button("A−", readerFontSize > 14, action = {
            readerFontSize = (readerFontSize - 2).coerceAtLeast(14)
            prefs.edit().putInt("reader_font", readerFontSize).apply()
            showReader(comic, chapterIndex)
        }), LinearLayout.LayoutParams(0, -2, 1f))
        readerTools.addView(button("A+", readerFontSize < 28, action = {
            readerFontSize = (readerFontSize + 2).coerceAtMost(28)
            prefs.edit().putInt("reader_font", readerFontSize).apply()
            showReader(comic, chapterIndex)
        }), LinearLayout.LayoutParams(0, -2, 1f))
        readerTools.addView(button(if (sepiaReader) "الوضع الداكن" else "لون دافئ", action = {
            sepiaReader = !sepiaReader
            prefs.edit().putBoolean("reader_sepia", sepiaReader).apply()
            showReader(comic, chapterIndex)
        }), LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(readerTools)
        content.addView(text("${comic.title}   •   ${chapter.title}", 21f, purple, true))
        val importedPageCount = pagesFor(comic, chapterIndex).size
        content.addView(text(if (importedPageCount > 0) "$importedPageCount صفحة مستوردة محفوظة داخل التطبيق" else "نص قصة أصلي • يعمل دون اتصال", 12f, if (sepiaReader) warmText else muted))
        content.addView(button(if (importedPageCount > 0) "استبدال صفحات الفصل من الجهاز" else "استيراد صفحات الفصل من الجهاز", action = { importPages(comic, chapterIndex) }))
        addImportedPages(comic, chapterIndex)
        chapter.paragraphs.forEachIndexed { index, paragraph ->
            content.addView(text(paragraph, readerFontSize.toFloat(), if (sepiaReader) warmText else white).apply {
                setPadding(10, 12, 10, 12)
                setLineSpacing(8f, 1.08f)
                val lp = LinearLayout.LayoutParams(-1, -2)
                lp.setMargins(0, 2, 0, 8)
                layoutParams = lp
            })
        }
        content.addView(text("نهاية ${chapter.title}", 14f, purple, true))
        content.addView(button(if (downloads.contains(keyFor(comic, chapterIndex))) "✓ الفصل محفوظ دون إنترنت" else "حفظ هذا الفصل دون إنترنت", action = {
            if (!downloads.contains(keyFor(comic, chapterIndex))) toggleDownload(comic, chapterIndex)
            showReader(comic, chapterIndex)
        }))
        content.addView(button("مشاركة اسم الفصل", action = { shareText("${comic.title} — ${chapter.title} | عالم المانجا") }))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        nav.addView(button("← الفصل التالي", chapterIndex < comic.chapters.lastIndex, action = {
            if (chapterIndex < comic.chapters.lastIndex) showReader(comic, chapterIndex + 1)
        }), LinearLayout.LayoutParams(0, -2, 1f))
        nav.addView(button("الفصل السابق →", chapterIndex > 0, action = {
            if (chapterIndex > 0) showReader(comic, chapterIndex - 1)
        }), LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(nav)
        content.addView(button("العودة إلى قائمة الفصول", action = { showComic(comic) }))
    }

    private fun shareText(value: String) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, value)
        }
        startActivity(Intent.createChooser(send, "مشاركة"))
    }

    private fun showFavorites() {
        activeScreen = "favorites"
        currentTab = "المفضلة"
        makeRoot("الأعمال التي حفظتها")
        val list = comics.filter { favorites.contains(it.title) }
        val onlineList = allOnlineWorks().filter { favorites.contains(it.title) }
        if (list.isEmpty() && onlineList.isEmpty()) content.addView(text("لسه مفيش أعمال في المفضلة. افتح الرئيسية واضغط ☆ بجانب أي عمل.", 14f, muted))
        onlineList.forEach { addOnlineWorkCard(content, it) }
        list.forEach { addComicCard(it) }
    }

    private fun showDownloads() {
        activeScreen = "downloads"
        currentTab = "المحفوظ"
        makeRoot("فصول محفوظة محليًا")
        if (downloads.isEmpty()) {
            content.addView(text("مفيش فصول محفوظة لحد الآن. افتح أي عمل واضغط «حفظ دون إنترنت».", 14f, muted))
            return
        }
        downloads.toList().forEach { key ->
            val parsed = parseKey(key)
            if (parsed != null) {
                val (comic, index) = parsed
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setBackgroundColor(panel)
                    setPadding(8, 5, 8, 5)
                }
                row.addView(text("⬇ ${comic.title}", 16f, white, true))
                row.addView(text(comic.chapters[index].title, 13f, muted))
                val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                actions.addView(button("افتح الفصل", action = { showReader(comic, index) }), LinearLayout.LayoutParams(0, -2, 1f))
                actions.addView(button("إلغاء الحفظ", action = {
                    downloads.remove(key)
                    saveSets()
                    showDownloads()
                }), LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(actions)
                val lp = LinearLayout.LayoutParams(-1, -2)
                lp.setMargins(0, 5, 0, 5)
                content.addView(row, lp)
            }
        }
        content.addView(text("المحفوظ هنا هو فصل تجريبي أصلي مضمّن داخل التطبيق، وليس تنزيلًا من موقع خارجي.", 12f, muted))
    }

    private fun showHistory() {
        activeScreen = "history"
        currentTab = "السجل"
        makeRoot("آخر ما قرأته")
        if (history.isEmpty()) {
            content.addView(text("سجل القراءة فاضي. أول ما تفتح فصل، هيظهر هنا تلقائيًا.", 14f, muted))
            return
        }
        history.toList().forEach { key ->
            val parsed = parseKey(key)
            if (parsed != null) {
                val (comic, index) = parsed
                content.addView(button("${comic.title} — ${comic.chapters[index].title}", action = { showReader(comic, index) }))
            }
        }
        content.addView(button("مسح سجل القراءة", action = {
            history.clear()
            prefs.edit().remove("history").remove("last_read").apply()
            showHistory()
        }))
    }

    override fun onDestroy() {
        activeWebView?.stopLoading()
        activeWebView?.destroy()
        activeWebView = null
        super.onDestroy()
    }

    @Deprecated("Deprecated in Android API; retained for compatibility with older Android versions")
    override fun onBackPressed() {
        when (activeScreen) {
            "sources", "online_library" -> showHome()
            "webreader" -> activeOnlineWork?.let { showOnlineWork(it) } ?: showHome()
            "online_detail" -> showOnlineLibrary()
            "reader" -> activeComic?.let { showComic(it) } ?: showHome()
            "detail" -> showHome()
            else -> if (currentTab != "الرئيسية") showHome() else super.onBackPressed()
        }
    }
}
