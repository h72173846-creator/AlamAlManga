package com.alamalmanga.app

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.net.Uri
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream

private data class Chapter(val title: String, val paragraphs: List<String>)
private data class Comic(
    val title: String,
    val kind: String,
    val genre: String,
    val description: String,
    val chapters: List<Chapter>
)

class MainActivity : Activity() {
    private val bg = Color.rgb(14, 16, 25)
    private val panel = Color.rgb(27, 30, 44)
    private val purple = Color.rgb(157, 112, 255)
    private val white = Color.rgb(247, 247, 252)
    private val muted = Color.rgb(181, 185, 205)
    private val warmBg = Color.rgb(245, 235, 211)
    private val warmPanel = Color.rgb(255, 248, 230)
    private val warmText = Color.rgb(63, 48, 32)

    private lateinit var prefs: SharedPreferences
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private val favorites = linkedSetOf<String>()
    private val downloads = linkedSetOf<String>()
    private val history = mutableListOf<String>()
    private var currentTab = "الرئيسية"
    private var filter = "الكل"
    private var readerFontSize = 18
    private var sepiaReader = false
    private var activeComic: Comic? = null
    private var activeChapterIndex = 0
    private var activeScreen = "home"
    private var importTarget: Pair<Comic, Int>? = null
    private val importPagesRequestCode = 4317

    // All sample chapters below are original text written for this demo app.
    private val comics = listOf(
        Comic(
            "رحلة الظلال", "مانجا", "مغامرات", "فتاة تكتشف أن الظلال تحفظ ذكريات المدينة المفقودة.",
            listOf(
                Chapter("الفصل 1: الظل الذي تأخر", listOf(
                    "في مدينة لا تنام، كانت ليان تعود إلى منزلها كل مساء عبر زقاق ضيق. في تلك الليلة لاحظت أن ظلها لم يتبعها؛ بقي واقفًا تحت مصباح الشارع، كأنه ينتظر شخصًا آخر.",
                    "اقتربت بحذر. لم يتحرك الظل، لكنه رسم بإصبعه بابًا على الجدار. ظهرت على الطوب خطوط زرقاء تشبه خريطة قديمة، ثم سمعت ليان صوتًا يهمس باسمها من الجهة الأخرى.",
                    "لم يكن الباب موجودًا قبل لحظة. أخذت نفسًا عميقًا ومدت يدها نحو المقبض البارد. خلفها، عادت كل ظلال الزقاق إلى أماكنها دفعة واحدة، بينما انفتح الباب على سماء مليئة بنجوم لم ترها من قبل."
                )),
                Chapter("الفصل 2: خريطة الذاكرة", listOf(
                    "امتد الطريق خلف الباب فوق بحر من الضباب. كانت النجوم تضيء كلما خطت ليان خطوة، وتخفت حين تتراجع. على حجر صغير وجدت خريطة تحمل أسماء شوارع مدينتها، لكن بجانب كل اسم تاريخًا يعود إلى مئة عام.",
                    "ظهر حارس يرتدي معطفًا رماديًا وقال إن الظلال ليست نسخًا من أصحابها، بل ذكريات نسوها مع مرور الزمن. ظل ليان تأخر لأنه تذكر شيئًا حاولت هي نسيانه.",
                    "أشارت الخريطة إلى برج الساعة في قلب المدينة. قبل أن تسأل عن السبب، انطفأت نجمة واحدة وسقطت في البحر. قال الحارس: حين تنطفئ النجوم كلها، ستنسى المدينة نفسها."
                )),
                Chapter("الفصل 3: برج الساعة", listOf(
                    "عادت ليان إلى المدينة مع أول ضوء للفجر. كان برج الساعة متوقفًا عند الثالثة وسبع عشرة دقيقة، والناس يمرون تحته دون أن يلاحظوا. وحدها القطط كانت تحدق في قمته.",
                    "داخل البرج، وجدت درجًا لا يظهر إلا في انعكاس الزجاج. صعدت وهي تسمع أصواتًا من طفولتها: ضحكة أمها، أغنية قديمة، ووعدًا قطعته لنفسها ثم نسيته.",
                    "في أعلى البرج، انتظرها ظلها. لم يكن يريد العودة فحسب؛ كان يحاول تحذيرها من شيء يتحرك تحت المدينة. وعندما دقت الساعة أخيرًا، انفتحت الأرض عن ضوء أزرق عميق."
                ))
            )
        ),
        Comic(
            "بوابة التنين", "مانهوا", "فانتازيا", "متدرّب خرائط يعثر على بوابة تستجيب للوعود الصادقة.",
            listOf(
                Chapter("الفصل 1: الوعد الحجري", listOf(
                    "كان يونس أصغر رسامي الخرائط في مملكة السحاب. لم يكن يجيد المبارزة أو السحر، لكنه يستطيع رسم طريق لم يره أحد من قبل. وفي يوم جرفته عاصفة إلى وادٍ لا يظهر على أي خريطة.",
                    "في نهاية الوادي وقف قوس حجري عليه نقش تنين بلا أجنحة. حين لمس يونس الحجر، سمع صوتًا يسأله: ما الشيء الذي لن تتخلى عنه مهما كان الثمن؟ أجاب بأنه لن يترك أخته تبحث عنه وحدها.",
                    "اشتعل النقش بضوء ذهبي، وفتحت البوابة على غابة معلقة في السماء. ومن داخلها خرجت فراشة معدنية تحمل رسالة مختومة باسم عائلته."
                )),
                Chapter("الفصل 2: الغابة المعلّقة", listOf(
                    "كانت الأشجار تنمو من جزر صخرية تطفو فوق بحر من الغيوم. ربط يونس خريطته بحزامه وتبع الفراشة حتى شجرة ضخمة جذورها تشبه السلالم.",
                    "وجد عند الجذع حارسًا صغيرًا اسمه رُبى. أخبرته أن البوابة تختبر الوعود، وأن كل وعد مكسور يترك شقًا في السماء. ظهر شق جديد فوقهما، وسقطت منه أحجار سوداء.",
                    "رسم يونس طريقًا بالقلم على الهواء، فتحول الخط إلى جسر من الحبر. عبر الاثنان قبل أن تنهار الجزيرة، لكن الرسالة في يد الفراشة بدأت تحترق من أطرافها."
                )),
                Chapter("الفصل 3: قلب البوابة", listOf(
                    "قادتهما الرسالة إلى معبد مخفي داخل جذور الشجرة. على الجدار لوحة لعائلة يونس، وبجانبها صورة امرأة تشبه أخته تمامًا.",
                    "كشف الحارس أن البوابة لا تفتح إلى أماكن بعيدة فقط، بل إلى القرارات التي لم يتخذها الناس. كان على يونس أن يختار بين طريق يعيده إلى بيته وطريق يكشف سر اختفاء والده.",
                    "طوى الخريطة ووضعها في جيبه. قال إنه سيبحث عن الحقيقة، لكنه سيعود إلى أخته مهما حدث. عندها ظهر على البوابة جناحان من نور، وسمع التنين يناديه باسمه الكامل."
                ))
            )
        ),
        Comic(
            "مدينة النجوم", "مانجا", "خيال علمي", "ميكانيكية شابة تحاول إعادة تشغيل منارة تحمي مدينة عائمة.",
            listOf(
                Chapter("الفصل 1: آخر منارة", listOf(
                    "منذ ثلاثين سنة، ظلت مدينة أوريون تطفو فوق الغلاف السحابي بفضل منارة هائلة في مركزها. وحين بدأت أضواؤها تنطفئ واحدة تلو الأخرى، لم يجرؤ أحد على الاقتراب من غرفة المحرك.",
                    "دخلت ميرا الغرفة ومعها حقيبة أدوات ودفتر تركه لها جدها. لم تجد محركًا، بل كرة صغيرة تدور حول نفسها وتطلق أصواتًا تشبه نداء الحيتان.",
                    "كتب جدها في الدفتر: لا تحاولي تشغيل المنارة بالقوة؛ اسأليها عمّا فقدته. وضعت ميرا يدها على الكرة، فظهر على الزجاج مشهد لمدينة أخرى تحت السحب، مدينة لم تسجلها أي أجهزة."
                )),
                Chapter("الفصل 2: الرسالة من الأسفل", listOf(
                    "صنعت ميرا جهاز إرسال من قطع قديمة، وأرسلت نمط الضوء الذي رأته على الكرة. بعد دقائق عاد الرد في صورة ثلاث ومضات طويلة وواحدة قصيرة.",
                    "فسّر مهندس المدينة الإشارة بأنها تحذير، لكن ميرا لاحظت أن النمط نفسه مرسوم في هامش دفتر جدها. كان جدها قد سافر إلى الأسفل قبل اختفاء المنارة بسنوات.",
                    "عند حافة المدينة وجدت مصعد صيانة مهجورًا. حين ضغطت الزر، اشتغل لأول مرة منذ عقود، وبدأ يهبط عبر الغيوم نحو أضواء تلمع في عمق الظلام."
                ))
            )
        ),
        Comic(
            "صياد الأبراج", "مانهوا", "أكشن", "طالبة تتسلق أبراجًا غامضة بحثًا عن سبب ظهورها في العالم.",
            listOf(
                Chapter("الفصل 1: الطابق صفر", listOf(
                    "ظهرت الأبراج في كل أنحاء العالم خلال ليلة واحدة. كان لكل برج باب أسود وشعار مختلف، ولم يستطع أحد فتحها حتى وقفت ندى أمام برج بلا شعار.",
                    "لم يظهر على جهازها مستوى أو مهمة، بل جملة واحدة: الطابق صفر مفتوح. دخلت فوجدت ساحة هادئة تتوسطها شجرة، وتحتها مقعد يحمل اسمها.",
                    "عندما جلست، ظهر رجل آلي مكسور وقال إن البرج لا يختبر القوة، بل القدرة على ملاحظة ما يتجاهله الآخرون. أشار إلى ظل الشجرة، حيث كانت هناك خطوات صغيرة تتجه إلى جدار مصمت."
                )),
                Chapter("الفصل 2: اختبار الملاحظة", listOf(
                    "لمست ندى الجدار عند نهاية الخطوات، فاختفى وظهر ممر مليء بأبواب متشابهة. لم تختَر الباب الأكبر أو الأكثر لمعانًا؛ راقبت الغبار ولاحظت أن بابًا واحدًا لا توجد أمامه آثار أقدام.",
                    "خلفه كانت غرفة تحكم قديمة، وعلى الطاولة سجل يحمل تواريخ ظهور الأبراج. كل سجل ينتهي في اليوم نفسه: يوم اختفاء شخص لم يتذكره أحد.",
                    "وصلت إلى آخر صفحة فوجدت صورتها وهي طفلة. قبل أن تقرأ التعليق، أضاءت شاشة صغيرة: مرحبًا بعودتك، المشغّل رقم واحد."
                ))
            )
        ),
        Comic(
            "مذكرات الساحر", "مانهوا", "فانتازيا", "ساحر مبتدئ يكتشف أن مذكراته تكتب أحداث الغد.",
            listOf(
                Chapter("الفصل 1: صفحة الغد", listOf(
                    "ورث سامر غرفة ضيقة ومجموعة كتب من معلمه الراحل. بين الكتب وجد دفترًا جلديًا فارغ الصفحات. كتب اسمه في الصفحة الأولى، فظهرت تحته جملة تصف المطر الذي سيبدأ بعد ساعة.",
                    "انتظر عند النافذة، فهطل المطر في الموعد تمامًا. كتب سؤالًا عن سبب اختفاء معلمه، لكن الحبر تراجع وحده وترك مكانه دائرة سوداء.",
                    "في الليل، سمع طرقًا على الباب. كانت امرأة تحمل مظلة جافة رغم المطر، وقالت إن الدفتر لا يتنبأ بالمستقبل؛ إنه يختار أي مستقبل سيصبح حقيقيًا."
                )),
                Chapter("الفصل 2: ثمن الحبر", listOf(
                    "أخبرت المرأة سامر أن كل كلمة في الدفتر تغيّر احتمالًا في العالم. الكلمات الصغيرة تغيّر تفاصيل بسيطة، أما الأسماء فتستطيع فتح أبواب كان يجب أن تبقى مغلقة.",
                    "حاول سامر كتابة اسم معلمه، لكن القلم رفض ترك أثر. بدلًا من ذلك، ظهر اسم جديد لم يسمعه من قبل: الحارس الأخير.",
                    "خرجت المرأة من الغرفة واختفت المظلة معها. في الدفتر، كُتبت جملة أخيرة بخط سامر نفسه: لا تثق بأول نسخة من قصتك."
                ))
            )
        ),
        Comic(
            "قناع الليل", "مانجا", "غموض", "رسام أقنعة يساعد حيّه على حل ألغاز تظهر بعد منتصف الليل.",
            listOf(
                Chapter("الفصل 1: القناع الأبيض", listOf(
                    "كان متجر نادر يغلق أبوابه عند منتصف الليل، إلا أن قناعًا أبيض كان يظهر كل صباح على العتبة. لم يعرف من صنعه، لكنه لاحظ أن كل قناع يقوده إلى لغز في الحي.",
                    "في الليلة السابعة، وجد القناع يحمل خيطًا أحمر متصلًا بباب المكتبة القديمة. في الداخل، كانت الكتب مرتبة حسب الأصوات لا حسب العناوين.",
                    "فتح نادر كتابًا صامتًا، فسقطت منه ورقة عليها رسم لشارع الحي من الأعلى. في منتصف الرسم توجد نافذة مضاءة في منزل مهجور منذ سنوات."
                )),
                Chapter("الفصل 2: نافذة لا تنام", listOf(
                    "وصل نادر إلى المنزل المهجور قبل الفجر. من الخارج بدا خاليًا، لكن النافذة المضيئة كشفت غرفة مرتبة ومكتبًا عليه أدوات رسم تشبه أدواته تمامًا.",
                    "على الجدار كانت هناك أقنعة لكل شخص في الحي، وتحت كل قناع ملاحظة عن شيء فقده صاحبه. لم تكن أسرارًا مخيفة؛ كانت وعودًا نسي أصحابها الوفاء بها.",
                    "عندما رفع القناع الأبيض عن الخطاف، انطفأت النافذة وسمع صوتًا خلفه يقول: الآن عرفت أين تبدأ الحكاية، لكن هل تستطيع إنهاءها؟"
                ))
            )
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("alam_al_manga", MODE_PRIVATE)
        favorites.addAll(prefs.getStringSet("favorites", emptySet()) ?: emptySet())
        downloads.addAll(prefs.getStringSet("downloads", emptySet()) ?: emptySet())
        readerFontSize = prefs.getInt("reader_font", 18).coerceIn(14, 28)
        sepiaReader = prefs.getBoolean("reader_sepia", false)
        val savedHistory = prefs.getString("history", "[]") ?: "[]"
        try {
            val array = JSONArray(savedHistory)
            for (i in 0 until array.length()) {
                val item = array.optString(i)
                if (item.isNotBlank() && !history.contains(item)) history.add(item)
            }
        } catch (_: Exception) { /* Ignore damaged local history and start fresh. */ }
        applySystemColors()
        showHome()
    }

    private fun applySystemColors() {
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
    }

    private fun saveSets() {
        prefs.edit()
            .putStringSet("favorites", HashSet(favorites))
            .putStringSet("downloads", HashSet(downloads))
            .apply()
    }

    private fun saveHistory() {
        val array = JSONArray()
        history.take(30).forEach { array.put(it) }
        prefs.edit().putString("history", array.toString()).apply()
    }

    private fun keyFor(comic: Comic, chapterIndex: Int) = "${comic.title}|||$chapterIndex"

    private fun parseKey(key: String): Pair<Comic, Int>? {
        val bits = key.split("|||")
        if (bits.size != 2) return null
        val comic = comics.firstOrNull { it.title == bits[0] } ?: return null
        val index = bits[1].toIntOrNull() ?: return null
        if (index !in comic.chapters.indices) return null
        return comic to index
    }

    private fun recordRead(comic: Comic, index: Int) {
        val key = keyFor(comic, index)
        history.remove(key)
        history.add(0, key)
        while (history.size > 30) history.removeAt(history.lastIndex)
        saveHistory()
        prefs.edit().putString("last_read", key).apply()
    }

    private fun text(value: String, size: Float = 16f, color: Int = white, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(if (activeScreen == "reader" && sepiaReader && color == white) warmText else color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.RIGHT
            textDirection = View.TEXT_DIRECTION_RTL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(8, 7, 8, 7)
            setLineSpacing(3f, 1.05f)
        }
    }

    private fun button(value: String, enabled: Boolean = true, action: () -> Unit): Button {
        return Button(this).apply {
            text = value
            setTextColor(if (activeScreen == "reader" && sepiaReader) warmText else white)
            textSize = 12f
            isAllCaps = false
            setBackgroundColor(if (activeScreen == "reader" && sepiaReader) Color.rgb(226, 211, 181) else panel)
            isEnabled = enabled
            alpha = if (enabled) 1f else 0.45f
            setOnClickListener { action() }
        }
    }

    private fun addGap(height: Int = 8) {
        content.addView(View(this), LinearLayout.LayoutParams(1, height))
    }

    private fun makeRoot(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(if (activeScreen == "reader" && sepiaReader) warmBg else bg)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(14, 8, 14, 6)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 2, 0, 5)
        }
        header.addView(text("عالم المانجا", 24f, purple, true))
        header.addView(text(title, 13f, if (activeScreen == "reader" && sepiaReader) warmText else muted))
        root.addView(header)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, 0, 0, 4)
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = false
            clipToPadding = false
            addView(content)
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 6, 0, 0)
        }
        listOf("الرئيسية", "بحث", "المفضلة", "المحفوظ", "السجل").forEach { tab ->
            nav.addView(button(tab, action = {
                currentTab = tab
                when (tab) {
                    "الرئيسية" -> showHome()
                    "بحث" -> showSearch()
                    "المفضلة" -> showFavorites()
                    "المحفوظ" -> showDownloads()
                    else -> showHistory()
                }
            }), LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        setContentView(root)
    }

    private fun addSectionTitle(value: String) {
        content.addView(text(value, 19f, white, true))
    }

    private fun showHome() {
        activeScreen = "home"
        currentTab = "الرئيسية"
        makeRoot("مكتبة عربية خفيفة للمانجا والمانهوا")
        val banner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
            setBackgroundColor(panel)
        }
        banner.addView(text("اقرأ قصصًا أصلية حتى بدون إنترنت", 18f, purple, true))
        banner.addView(text("مفضلة محفوظة • سجل قراءة • قارئ قابل للتخصيص • فصول تجريبية مدمجة", 13f, muted))
        val resumeKey = prefs.getString("last_read", null)
        val resumeTarget = resumeKey?.let { parseKey(it) }
        if (resumeTarget != null) {
            banner.addView(button("▶ متابعة القراءة: ${resumeTarget.first.title}", action = {
                showReader(resumeTarget.first, resumeTarget.second)
            }))
        } else {
            banner.addView(button("اكتشف أول قصة", action = { showComic(comics.first()) }))
        }
        content.addView(banner)
        addGap()

        val categoryRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("الكل", "مانجا", "مانهوا").forEach { category ->
            categoryRow.addView(button(if (filter == category) "● $category" else category, action = {
                filter = category
                showHome()
            }), LinearLayout.LayoutParams(0, -2, 1f))
        }
        content.addView(categoryRow)
        addSectionTitle(if (filter == "الكل") "أعمال مقترحة" else "${filter} مختارة")
        comics.filter { filter == "الكل" || it.kind == filter }.forEach { addComicCard(it) }
        addGap()
        addSectionTitle("مميزات النسخة")
        content.addView(text("• يحفظ المفضلة والفصول المحفوظة وسجل القراءة على جهازك.\n• نصوص قصص تجريبية أصلية متاحة دون اتصال.\n• حجم خط القارئ ووضع القراءة الدافئ قابلان للتغيير.", 13f, muted))
        content.addView(text("ملاحظة: المكتبة الحالية نموذج قابل للتوسعة، وليست مكتبة الأعمال التجارية الكاملة. إضافة مانجا منشورة أو تنزيلها تحتاج مصدرًا مرخصًا وملفات متاحة قانونيًا.", 12f, muted))
    }

    private fun addComicCard(comic: Comic) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(panel)
            setPadding(10, 7, 10, 7)
        }
        card.addView(text("📚  ${comic.title}", 18f, white, true))
        card.addView(text("${comic.kind}  •  ${comic.genre}  •  ${comic.chapters.size} فصول", 12f, purple, true))
        card.addView(text(comic.description, 13f, muted))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("اقرأ العمل", action = { showComic(comic) }), LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(button(if (favorites.contains(comic.title)) "★ محفوظ" else "☆ المفضلة", action = {
            toggleFavorite(comic)
            if (activeScreen == "favorites") showFavorites() else if (activeScreen == "detail") showComic(comic) else showHome()
        }), LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(actions)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 6, 0, 6)
        content.addView(card, lp)
    }

    private fun toggleFavorite(comic: Comic) {
        if (!favorites.add(comic.title)) favorites.remove(comic.title)
        saveSets()
        Toast.makeText(this, if (favorites.contains(comic.title)) "أُضيف إلى المفضلة" else "أُزيل من المفضلة", Toast.LENGTH_SHORT).show()
    }

    private fun showSearch() {
        activeScreen = "search"
        currentTab = "بحث"
        makeRoot("ابحث عن عنوان أو نوع أو تصنيف")
        val input = EditText(this).apply {
            hint = "مثال: فانتازيا، مانجا، رحلة الظلال"
            setHintTextColor(muted)
            setTextColor(white)
            textDirection = View.TEXT_DIRECTION_RTL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setSingleLine(true)
            setPadding(12, 10, 12, 10)
            setBackgroundColor(panel)
        }
        content.addView(input)
        val results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(results)
        fun refresh(query: String) {
            results.removeAllViews()
            val q = query.trim()
            val found = comics.filter {
                q.isEmpty() || it.title.contains(q, true) || it.kind.contains(q, true) ||
                    it.genre.contains(q, true) || it.description.contains(q, true)
            }
            if (found.isEmpty()) results.addView(text("مفيش نتائج مطابقة. جرّب كلمة تانية.", 14f, muted))
            else found.forEach { addComicCardTo(results, it) }
        }
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { refresh(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: Editable?) = Unit
        })
        refresh("")
    }

    private fun addComicCardTo(target: LinearLayout, comic: Comic) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(panel)
            setPadding(8, 5, 8, 5)
        }
        row.addView(text(comic.title, 17f, white, true))
        row.addView(text("${comic.kind} • ${comic.genre}", 12f, purple))
        row.addView(button("فتح العمل", action = { showComic(comic) }))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 5, 0, 5)
        target.addView(row, lp)
    }

    private fun showComic(comic: Comic) {
        activeScreen = "detail"
        activeComic = comic
        currentTab = ""
        makeRoot(comic.title)
        content.addView(text("${comic.kind} • ${comic.genre} • ${comic.chapters.size} فصول", 14f, purple, true))
        content.addView(text(comic.description, 15f, muted))
        content.addView(button(if (favorites.contains(comic.title)) "★ إزالة من المفضلة" else "☆ إضافة إلى المفضلة", action = {
            toggleFavorite(comic)
            showComic(comic)
        }))
        addSectionTitle("الفصول المتاحة دون إنترنت")
        comic.chapters.forEachIndexed { index, chapter ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(panel)
                setPadding(8, 4, 8, 4)
            }
            item.addView(text("${index + 1}. ${chapter.title}", 15f, white, true))
            val pageCount = pagesFor(comic, index).size
            val status = if (pageCount > 0) "$pageCount صفحة مستوردة ومحفوظة" else if (downloads.contains(keyFor(comic, index))) "✓ نص محفوظ على الجهاز" else "نص أصلي مدمج داخل التطبيق"
            item.addView(text(status, 12f, muted))
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            actions.addView(button("قراءة", action = { showReader(comic, index) }), LinearLayout.LayoutParams(0, -2, 1f))
            actions.addView(button(if (downloads.contains(keyFor(comic, index))) "إلغاء الحفظ" else "حفظ دون إنترنت", action = {
                toggleDownload(comic, index)
                showComic(comic)
            }), LinearLayout.LayoutParams(0, -2, 1f))
            item.addView(actions)
            item.addView(button("استيراد صفحات من جهازك", action = { importPages(comic, index) }))
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.setMargins(0, 5, 0, 5)
            content.addView(item, lp)
        }
        content.addView(button("مشاركة اسم العمل", action = { shareText("${comic.title} — عالم المانجا") }))
    }

    private fun toggleDownload(comic: Comic, index: Int) {
        val key = keyFor(comic, index)
        if (downloads.contains(key)) downloads.remove(key) else downloads.add(key)
        saveSets()
        Toast.makeText(this, if (downloads.contains(key)) "تم حفظ الفصل محليًا للرجوع إليه دون إنترنت" else "تم إلغاء الحفظ", Toast.LENGTH_SHORT).show()
    }

    private fun pagesPrefKey(comic: Comic, chapterIndex: Int): String =
        "pages_${Integer.toHexString(keyFor(comic, chapterIndex).hashCode())}"

    private fun pageDirectory(comic: Comic, chapterIndex: Int): File {
        val folderName = "chapter_${Integer.toHexString(keyFor(comic, chapterIndex).hashCode())}"
        return File(File(filesDir, "chapter_pages"), folderName)
    }

    private fun pagesFor(comic: Comic, chapterIndex: Int): List<String> {
        return try {
            val array = JSONArray(prefs.getString(pagesPrefKey(comic, chapterIndex), "[]") ?: "[]")
            (0 until array.length()).map { array.optString(it) }.filter { it.isNotBlank() }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun importPages(comic: Comic, chapterIndex: Int) {
        importTarget = comic to chapterIndex
        val picker = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            putExtra(Intent.EXTRA_TITLE, "اختر صفحات الفصل")
        }
        try {
            startActivityForResult(picker, importPagesRequestCode)
        } catch (_: Exception) {
            importTarget = null
            Toast.makeText(this, "تعذر فتح مدير الملفات على هذا الجهاز", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Android API; retained for compatibility with Android 6+")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != importPagesRequestCode || resultCode != RESULT_OK) return
        val target = importTarget ?: return
        importTarget = null
        val uris = mutableListOf<Uri>()
        val clip = data?.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) clip.getItemAt(i).uri?.let { uris.add(it) }
        } else {
            data?.data?.let { uris.add(it) }
        }
        if (uris.isEmpty()) {
            Toast.makeText(this, "لم يتم اختيار صور", Toast.LENGTH_SHORT).show()
            return
        }
        val (comic, chapterIndex) = target
        val folder = pageDirectory(comic, chapterIndex)
        if (!folder.exists()) folder.mkdirs()
        folder.listFiles()?.forEach { it.delete() }
        val copied = mutableListOf<String>()
        uris.take(50).forEachIndexed { index, uri ->
            val outputFile = File(folder, "page_${(index + 1).toString().padStart(3, '0')}.img")
            try {
                val input = contentResolver.openInputStream(uri)
                if (input != null) {
                    input.use { source ->
                        FileOutputStream(outputFile).use { output ->
                            val buffer = ByteArray(8192)
                            var total = 0L
                            while (true) {
                                val count = source.read(buffer)
                                if (count <= 0) break
                                total += count
                                if (total > 40L * 1024L * 1024L) throw IllegalStateException("الصورة أكبر من 40 ميجابايت")
                                output.write(buffer, 0, count)
                            }
                        }
                    }
                    if (outputFile.exists() && outputFile.length() > 0L) copied.add(outputFile.name)
                    else outputFile.delete()
                }
            } catch (_: Exception) {
                outputFile.delete()
            }
        }
        prefs.edit().putString(pagesPrefKey(comic, chapterIndex), JSONArray(copied).toString()).apply()
        Toast.makeText(
            this,
            if (copied.isEmpty()) "لم أستطع استيراد الصور. جرّب صورًا أصغر." else "تم حفظ ${copied.size} صفحة داخل التطبيق دون إنترنت",
            Toast.LENGTH_LONG
        ).show()
        showReader(comic, chapterIndex)
    }

    private fun addImportedPages(comic: Comic, chapterIndex: Int) {
        val names = pagesFor(comic, chapterIndex)
        if (names.isEmpty()) return
        val folder = pageDirectory(comic, chapterIndex)
        content.addView(text("صفحاتك المستوردة (${names.size})", 18f, purple, true))
        names.forEachIndexed { index, name ->
            val pageFile = File(folder, name)
            if (!pageFile.isFile) return@forEachIndexed
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(pageFile.absolutePath, options)
            val maxWidth = (resources.displayMetrics.widthPixels - (32 * resources.displayMetrics.density).toInt()).coerceAtLeast(320)
            var sample = 1
            while (options.outWidth / sample > maxWidth * 2 || options.outHeight / sample > 4096) sample *= 2
            val bitmap = BitmapFactory.decodeFile(pageFile.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
            if (bitmap != null) {
                content.addView(text("صفحة ${index + 1}", 12f, muted))
                val image = ImageView(this).apply {
                    setImageBitmap(bitmap)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    adjustViewBounds = true
                    contentDescription = "صفحة ${index + 1} من ${comic.title}"
                    setBackgroundColor(if (sepiaReader) warmPanel else panel)
                    setPadding(2, 2, 2, 2)
                }
                val lp = LinearLayout.LayoutParams(-1, -2)
                lp.setMargins(0, 3, 0, 10)
                content.addView(image, lp)
            }
        }
    }

    private fun showReader(comic: Comic, chapterIndex: Int) {
        if (chapterIndex !in comic.chapters.indices) return
        activeScreen = "reader"
        activeComic = comic
        activeChapterIndex = chapterIndex
        recordRead(comic, chapterIndex)
        val chapter = comic.chapters[chapterIndex]
        makeRoot("${comic.title} — ${chapter.title}")

        val readerTools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        readerTools.addView(button("A−", readerFontSize > 14, action = {
            readerFontSize = (readerFontSize - 2).coerceAtLeast(14)
            prefs.edit().putInt("reader_font", readerFontSize).apply()
            showReader(comic, chapterIndex)
        }), LinearLayout.LayoutParams(0, -2, 1f))
        readerTools.addView(button("A+", readerFontSize < 28, action = {
            readerFontSize = (readerFontSize + 2).coerceAtMost(28)
            prefs.edit().putInt("reader_font", readerFontSize).apply()
            showReader(comic, chapterIndex)
        }), LinearLayout.LayoutParams(0, -2, 1f))
        readerTools.addView(button(if (sepiaReader) "الوضع الداكن" else "لون دافئ", action = {
            sepiaReader = !sepiaReader
            prefs.edit().putBoolean("reader_sepia", sepiaReader).apply()
            showReader(comic, chapterIndex)
        }), LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(readerTools)
        content.addView(text("${comic.title}   •   ${chapter.title}", 21f, purple, true))
        val importedPageCount = pagesFor(comic, chapterIndex).size
        content.addView(text(if (importedPageCount > 0) "$importedPageCount صفحة مستوردة محفوظة داخل التطبيق" else "نص قصة أصلي • يعمل دون اتصال", 12f, if (sepiaReader) warmText else muted))
        content.addView(button(if (importedPageCount > 0) "استبدال صفحات الفصل من الجهاز" else "استيراد صفحات الفصل من الجهاز", action = { importPages(comic, chapterIndex) }))
        addImportedPages(comic, chapterIndex)
        chapter.paragraphs.forEachIndexed { index, paragraph ->
            content.addView(text(paragraph, readerFontSize.toFloat(), if (sepiaReader) warmText else white).apply {
                setPadding(10, 12, 10, 12)
                setLineSpacing(8f, 1.08f)
                val lp = LinearLayout.LayoutParams(-1, -2)
                lp.setMargins(0, 2, 0, 8)
                layoutParams = lp
            })
        }
        content.addView(text("نهاية ${chapter.title}", 14f, purple, true))
        content.addView(button(if (downloads.contains(keyFor(comic, chapterIndex))) "✓ الفصل محفوظ دون إنترنت" else "حفظ هذا الفصل دون إنترنت", action = {
            if (!downloads.contains(keyFor(comic, chapterIndex))) toggleDownload(comic, chapterIndex)
            showReader(comic, chapterIndex)
        }))
        content.addView(button("مشاركة اسم الفصل", action = { shareText("${comic.title} — ${chapter.title} | عالم المانجا") }))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        nav.addView(button("← الفصل التالي", chapterIndex < comic.chapters.lastIndex, action = {
            if (chapterIndex < comic.chapters.lastIndex) showReader(comic, chapterIndex + 1)
        }), LinearLayout.LayoutParams(0, -2, 1f))
        nav.addView(button("الفصل السابق →", chapterIndex > 0, action = {
            if (chapterIndex > 0) showReader(comic, chapterIndex - 1)
        }), LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(nav)
        content.addView(button("العودة إلى قائمة الفصول", action = { showComic(comic) }))
    }

    private fun shareText(value: String) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, value)
        }
        startActivity(Intent.createChooser(send, "مشاركة"))
    }

    private fun showFavorites() {
        activeScreen = "favorites"
        currentTab = "المفضلة"
        makeRoot("الأعمال التي حفظتها")
        val list = comics.filter { favorites.contains(it.title) }
        if (list.isEmpty()) content.addView(text("لسه مفيش أعمال في المفضلة. افتح الرئيسية واضغط ☆ بجانب أي عمل.", 14f, muted))
        list.forEach { addComicCard(it) }
    }

    private fun showDownloads() {
        activeScreen = "downloads"
        currentTab = "المحفوظ"
        makeRoot("فصول محفوظة محليًا")
        if (downloads.isEmpty()) {
            content.addView(text("مفيش فصول محفوظة لحد الآن. افتح أي عمل واضغط «حفظ دون إنترنت».", 14f, muted))
            return
        }
        downloads.toList().forEach { key ->
            val parsed = parseKey(key)
            if (parsed != null) {
                val (comic, index) = parsed
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setBackgroundColor(panel)
                    setPadding(8, 5, 8, 5)
                }
                row.addView(text("⬇ ${comic.title}", 16f, white, true))
                row.addView(text(comic.chapters[index].title, 13f, muted))
                val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                actions.addView(button("افتح الفصل", action = { showReader(comic, index) }), LinearLayout.LayoutParams(0, -2, 1f))
                actions.addView(button("إلغاء الحفظ", action = {
                    downloads.remove(key)
                    saveSets()
                    showDownloads()
                }), LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(actions)
                val lp = LinearLayout.LayoutParams(-1, -2)
                lp.setMargins(0, 5, 0, 5)
                content.addView(row, lp)
            }
        }
        content.addView(text("المحفوظ هنا هو فصل تجريبي أصلي مضمّن داخل التطبيق، وليس تنزيلًا من موقع خارجي.", 12f, muted))
    }

    private fun showHistory() {
        activeScreen = "history"
        currentTab = "السجل"
        makeRoot("آخر ما قرأته")
        if (history.isEmpty()) {
            content.addView(text("سجل القراءة فاضي. أول ما تفتح فصل، هيظهر هنا تلقائيًا.", 14f, muted))
            return
        }
        history.toList().forEach { key ->
            val parsed = parseKey(key)
            if (parsed != null) {
                val (comic, index) = parsed
                content.addView(button("${comic.title} — ${comic.chapters[index].title}", action = { showReader(comic, index) }))
            }
        }
        content.addView(button("مسح سجل القراءة", action = {
            history.clear()
            prefs.edit().remove("history").remove("last_read").apply()
            showHistory()
        }))
    }

    @Deprecated("Deprecated in Android API; retained for compatibility with older Android versions")
    override fun onBackPressed() {
        when (activeScreen) {
            "reader" -> activeComic?.let { showComic(it) } ?: showHome()
            "detail" -> showHome()
            else -> if (currentTab != "الرئيسية") showHome() else super.onBackPressed()
        }
    }
}
